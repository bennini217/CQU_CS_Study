
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "E:/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/src/ir/ir_function.cpp" "CMakeFiles/IR.dir/src/ir/ir_function.cpp.obj" "gcc" "CMakeFiles/IR.dir/src/ir/ir_function.cpp.obj.d"
  "E:/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/src/ir/ir_instruction.cpp" "CMakeFiles/IR.dir/src/ir/ir_instruction.cpp.obj" "gcc" "CMakeFiles/IR.dir/src/ir/ir_instruction.cpp.obj.d"
  "E:/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/src/ir/ir_operand.cpp" "CMakeFiles/IR.dir/src/ir/ir_operand.cpp.obj" "gcc" "CMakeFiles/IR.dir/src/ir/ir_operand.cpp.obj.d"
  "E:/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/src/ir/ir_operator.cpp" "CMakeFiles/IR.dir/src/ir/ir_operator.cpp.obj" "gcc" "CMakeFiles/IR.dir/src/ir/ir_operator.cpp.obj.d"
  "E:/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/src/ir/ir_program.cpp" "CMakeFiles/IR.dir/src/ir/ir_program.cpp.obj" "gcc" "CMakeFiles/IR.dir/src/ir/ir_program.cpp.obj.d"
  "E:/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/src/ir/type.cpp" "CMakeFiles/IR.dir/src/ir/type.cpp.obj" "gcc" "CMakeFiles/IR.dir/src/ir/type.cpp.obj.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
