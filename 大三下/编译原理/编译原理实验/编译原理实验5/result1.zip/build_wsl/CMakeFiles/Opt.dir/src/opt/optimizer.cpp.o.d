CMakeFiles/Opt.dir/src/opt/optimizer.cpp.o: \
 /mnt/e/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/src/opt/optimizer.cpp \
 /usr/include/stdc-predef.h \
 /mnt/e/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/./include/opt/optimizer.h \
 /mnt/e/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/./include/ir/ir.h \
 /mnt/e/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/./include/ir/ir_operand.h \
 /usr/include/c++/13/string /usr/include/c++/13/bits/requires_hosted.h \
 /usr/include/x86_64-linux-gnu/c++/13/bits/c++config.h \
 /usr/include/x86_64-linux-gnu/c++/13/bits/os_defines.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/bits/timesize.h \
 /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/long-double.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/x86_64-linux-gnu/c++/13/bits/cpu_defines.h \
 /usr/include/c++/13/bits/stringfwd.h \
 /usr/include/c++/13/bits/memoryfwd.h \
 /usr/include/c++/13/bits/char_traits.h \
 /usr/include/c++/13/bits/postypes.h /usr/include/c++/13/cwchar \
 /usr/include/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
 /usr/include/x86_64-linux-gnu/bits/floatn.h \
 /usr/include/x86_64-linux-gnu/bits/floatn-common.h \
 /usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h \
 /usr/lib/gcc/x86_64-linux-gnu/13/include/stdarg.h \
 /usr/include/x86_64-linux-gnu/bits/wchar.h \
 /usr/include/x86_64-linux-gnu/bits/types/wint_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/mbstate_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__mbstate_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/locale_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/c++/13/type_traits /usr/include/c++/13/bits/allocator.h \
 /usr/include/x86_64-linux-gnu/c++/13/bits/c++allocator.h \
 /usr/include/c++/13/bits/new_allocator.h /usr/include/c++/13/new \
 /usr/include/c++/13/bits/exception.h \
 /usr/include/c++/13/bits/functexcept.h \
 /usr/include/c++/13/bits/exception_defines.h \
 /usr/include/c++/13/bits/move.h \
 /usr/include/c++/13/bits/cpp_type_traits.h \
 /usr/include/c++/13/bits/localefwd.h \
 /usr/include/x86_64-linux-gnu/c++/13/bits/c++locale.h \
 /usr/include/c++/13/clocale /usr/include/locale.h \
 /usr/include/x86_64-linux-gnu/bits/locale.h /usr/include/c++/13/iosfwd \
 /usr/include/c++/13/cctype /usr/include/ctype.h \
 /usr/include/x86_64-linux-gnu/bits/types.h \
 /usr/include/x86_64-linux-gnu/bits/typesizes.h \
 /usr/include/x86_64-linux-gnu/bits/time64.h \
 /usr/include/x86_64-linux-gnu/bits/endian.h \
 /usr/include/x86_64-linux-gnu/bits/endianness.h \
 /usr/include/c++/13/bits/ostream_insert.h \
 /usr/include/c++/13/bits/cxxabi_forced.h \
 /usr/include/c++/13/bits/stl_iterator_base_funcs.h \
 /usr/include/c++/13/bits/concept_check.h \
 /usr/include/c++/13/debug/assertions.h \
 /usr/include/c++/13/bits/stl_iterator_base_types.h \
 /usr/include/c++/13/bits/stl_iterator.h \
 /usr/include/c++/13/ext/type_traits.h \
 /usr/include/c++/13/bits/ptr_traits.h \
 /usr/include/c++/13/bits/stl_function.h \
 /usr/include/c++/13/backward/binders.h \
 /usr/include/c++/13/ext/numeric_traits.h \
 /usr/include/c++/13/bits/stl_algobase.h \
 /usr/include/c++/13/bits/stl_pair.h /usr/include/c++/13/bits/utility.h \
 /usr/include/c++/13/debug/debug.h \
 /usr/include/c++/13/bits/predefined_ops.h /usr/include/c++/13/bit \
 /usr/include/c++/13/bits/refwrap.h /usr/include/c++/13/bits/invoke.h \
 /usr/include/c++/13/bits/range_access.h \
 /usr/include/c++/13/initializer_list \
 /usr/include/c++/13/bits/basic_string.h \
 /usr/include/c++/13/ext/alloc_traits.h \
 /usr/include/c++/13/bits/alloc_traits.h \
 /usr/include/c++/13/bits/stl_construct.h \
 /usr/include/c++/13/ext/string_conversions.h /usr/include/c++/13/cstdlib \
 /usr/include/stdlib.h /usr/include/x86_64-linux-gnu/bits/waitflags.h \
 /usr/include/x86_64-linux-gnu/bits/waitstatus.h \
 /usr/include/x86_64-linux-gnu/sys/types.h \
 /usr/include/x86_64-linux-gnu/bits/types/clock_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/clockid_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/time_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/timer_t.h \
 /usr/include/x86_64-linux-gnu/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/x86_64-linux-gnu/bits/byteswap.h \
 /usr/include/x86_64-linux-gnu/bits/uintn-identity.h \
 /usr/include/x86_64-linux-gnu/sys/select.h \
 /usr/include/x86_64-linux-gnu/bits/select.h \
 /usr/include/x86_64-linux-gnu/bits/types/sigset_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__sigset_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_timeval.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_timespec.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes.h \
 /usr/include/x86_64-linux-gnu/bits/thread-shared-types.h \
 /usr/include/x86_64-linux-gnu/bits/pthreadtypes-arch.h \
 /usr/include/x86_64-linux-gnu/bits/atomic_wide_counter.h \
 /usr/include/x86_64-linux-gnu/bits/struct_mutex.h \
 /usr/include/x86_64-linux-gnu/bits/struct_rwlock.h /usr/include/alloca.h \
 /usr/include/x86_64-linux-gnu/bits/stdlib-float.h \
 /usr/include/c++/13/bits/std_abs.h /usr/include/c++/13/cstdio \
 /usr/include/stdio.h /usr/include/x86_64-linux-gnu/bits/types/__fpos_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__fpos64_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/struct_FILE.h \
 /usr/include/x86_64-linux-gnu/bits/types/cookie_io_functions_t.h \
 /usr/include/x86_64-linux-gnu/bits/stdio_lim.h \
 /usr/include/c++/13/cerrno /usr/include/errno.h \
 /usr/include/x86_64-linux-gnu/bits/errno.h /usr/include/linux/errno.h \
 /usr/include/x86_64-linux-gnu/asm/errno.h \
 /usr/include/asm-generic/errno.h /usr/include/asm-generic/errno-base.h \
 /usr/include/x86_64-linux-gnu/bits/types/error_t.h \
 /usr/include/c++/13/bits/charconv.h \
 /usr/include/c++/13/bits/functional_hash.h \
 /usr/include/c++/13/bits/hash_bytes.h \
 /usr/include/c++/13/bits/basic_string.tcc \
 /mnt/e/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/./include/ir/ir_operator.h \
 /mnt/e/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/./include/ir/ir_instruction.h \
 /usr/include/c++/13/vector /usr/include/c++/13/bits/stl_uninitialized.h \
 /usr/include/c++/13/bits/stl_vector.h \
 /usr/include/c++/13/bits/stl_bvector.h \
 /usr/include/c++/13/bits/vector.tcc \
 /mnt/e/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/./include/ir/ir_function.h \
 /mnt/e/专业课/大三下/编译原理/编译原理实验/编译原理实验5/1684995969759022838/./include/ir/ir_program.h \
 /usr/include/c++/13/cmath /usr/include/math.h \
 /usr/include/x86_64-linux-gnu/bits/math-vector.h \
 /usr/include/x86_64-linux-gnu/bits/libm-simd-decl-stubs.h \
 /usr/include/x86_64-linux-gnu/bits/flt-eval-method.h \
 /usr/include/x86_64-linux-gnu/bits/fp-logb.h \
 /usr/include/x86_64-linux-gnu/bits/fp-fast.h \
 /usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h \
 /usr/include/x86_64-linux-gnu/bits/mathcalls.h \
 /usr/include/x86_64-linux-gnu/bits/mathcalls-narrow.h \
 /usr/include/x86_64-linux-gnu/bits/iscanonical.h \
 /usr/include/c++/13/unordered_map \
 /usr/include/c++/13/bits/unordered_map.h \
 /usr/include/c++/13/bits/hashtable.h \
 /usr/include/c++/13/bits/hashtable_policy.h /usr/include/c++/13/tuple \
 /usr/include/c++/13/bits/uses_allocator.h \
 /usr/include/c++/13/ext/aligned_buffer.h \
 /usr/include/c++/13/bits/enable_special_members.h \
 /usr/include/c++/13/bits/erase_if.h
