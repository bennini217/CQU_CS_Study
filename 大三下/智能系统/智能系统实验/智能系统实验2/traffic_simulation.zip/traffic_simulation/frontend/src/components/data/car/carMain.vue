<template>
    <el-config-provider>
        <el-container>
            <div class="col-12 mb-2">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center">
                    <h6 class="active h6 sub_menu_title">
                        <span>车流量管理 (Traffic Logs)</span>
                    </h6>
                </div>
            </div>
        </el-container>
        <div class="table-responsive">
            <div class="col-12">
                <el-card class="box-card">
                    <div class="table-responsive pt-3 pb-3">
                        <el-table :data="logs" border style="width: 100%">
                            <el-table-column label="ID" prop="id" width="60"></el-table-column>
                            <el-table-column label="时间" prop="timestamp" width="180"></el-table-column>
                            <el-table-column label="路口" prop="intersection_id" width="80"></el-table-column>
                            <el-table-column label="来源" prop="data_source" width="120"></el-table-column>
                            <el-table-column label="传感器触发" width="100">
                                <template #default="scope">
                                    <el-tag :type="scope.row.sensor_triggered ? 'danger' : 'info'">
                                        {{ scope.row.sensor_triggered ? '是' : '否' }}
                                    </el-tag>
                                </template>
                            </el-table-column>
                            <el-table-column label="南北左转(车/秒)">
                                <template #default="scope">{{ scope.row.ns_l_cars }}辆 / {{ scope.row.ns_l_time }}秒</template>
                            </el-table-column>
                            <el-table-column label="南北直右(车/秒)">
                                <template #default="scope">{{ scope.row.ns_sr_cars }}辆 / {{ scope.row.ns_sr_time }}秒</template>
                            </el-table-column>
                            <el-table-column label="东西左转(车/秒)">
                                <template #default="scope">{{ scope.row.ew_l_cars }}辆 / {{ scope.row.ew_l_time }}秒</template>
                            </el-table-column>
                            <el-table-column label="东西直右(车/秒)">
                                <template #default="scope">{{ scope.row.ew_sr_cars }}辆 / {{ scope.row.ew_sr_time }}秒</template>
                            </el-table-column>
                        </el-table>
                    </div>
                </el-card>
            </div>
        </div>
    </el-config-provider>
</template>

<script>
import { ref, onMounted } from 'vue'
import util from '../../../util.js'
const { get } = util

export default {
    name: 'CarMain',
    setup() {
        const logs = ref([])

        const fetchLogs = async () => {
            try {
                const res = await get('/api/traffic_logs/')
                if (res && res.data && res.data.data) {
                    logs.value = res.data.data
                } else if (res && res.data) {
                    logs.value = res.data
                }
            } catch (error) {
                console.error("获取日志失败:", error)
            }
        }

        onMounted(() => {
            fetchLogs()
        })

        return { logs }
    }
}
</script>
