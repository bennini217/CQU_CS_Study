<template>
    <el-config-provider>
        <el-container>
            <div class="col-12 mb-2">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center">
                    <h6 class="active h6 sub_menu_title">
                        <span>可信知识管理 (Credibility Rules)</span>
                    </h6>
                </div>
            </div>
        </el-container>
        <div class="table-responsive">
            <div class="col-12">
                <el-card class="box-card">
                    <div class="table-responsive pt-3 pb-3">
                        <el-table :data="rules" border style="width: 100%">
                            <el-table-column label="ID" prop="rule_id" width="60"></el-table-column>
                            <el-table-column label="规则名称" prop="rule_name" width="180"></el-table-column>
                            <el-table-column label="前提目标" prop="premise_target"></el-table-column>
                            <el-table-column label="前提条件" prop="premise_condition"></el-table-column>
                            <el-table-column label="结论目标" prop="conclusion_target"></el-table-column>
                            <el-table-column label="结论动作" prop="conclusion_action"></el-table-column>
                            <el-table-column label="可信度 (CF)" prop="cf_value" width="100"></el-table-column>
                        </el-table>
                    </div>
                </el-card>
            </div>
        </div>
    </el-config-provider>
</template>

<script>
import { ref, onMounted } from 'vue'
import util from '../../../util.js'
const { get } = util

export default {
    name: 'Trustworthy',
    setup() {
        const rules = ref([])

        const fetchRules = async () => {
            try {
                const res = await get('/api/knowledge/credibility')
                if (res && res.data && res.data.data) {
                    rules.value = res.data.data
                } else if (res && res.data) {
                    rules.value = res.data
                }
            } catch (error) {
                console.error("获取可信度规则失败:", error)
            }
        }

        onMounted(() => {
            fetchRules()
        })

        return { rules }
    }
}
</script>
