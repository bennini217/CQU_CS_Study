<template>
    <el-config-provider>
        <el-container>
            <div class="col-12 mb-2">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center">
                    <h6 class="active h6 sub_menu_title">
                        <span>模糊知识管理 (Fuzzy Rules & Membership)</span>
                    </h6>
                </div>
            </div>
        </el-container>
        
        <div class="row">
            <!-- 模糊规则表 -->
            <div class="col-12 mb-4">
                <el-card class="box-card">
                    <template #header>
                        <div class="card-header">
                            <span>模糊控制规则</span>
                        </div>
                    </template>
                    <el-table :data="fuzzyRules" border style="width: 100%">
                        <el-table-column label="ID" prop="rule_id" width="60"></el-table-column>
                        <el-table-column label="规则名称" prop="rule_name" width="150"></el-table-column>
                        <el-table-column label="前提:南北车流" prop="condition_ns" width="120"></el-table-column>
                        <el-table-column label="前提:东西车流" prop="condition_ew" width="120"></el-table-column>
                        <el-table-column label="目标方向" prop="target_direction" width="120"></el-table-column>
                        <el-table-column label="结果时长" prop="result_time" width="100"></el-table-column>
                        <el-table-column label="权重" prop="weight" width="80"></el-table-column>
                        <el-table-column label="说明" prop="description"></el-table-column>
                    </el-table>
                </el-card>
            </div>

            <!-- 隶属函数表 -->
            <div class="col-12">
                <el-card class="box-card">
                    <template #header>
                        <div class="card-header">
                            <span>隶属函数参数定义</span>
                        </div>
                    </template>
                    <el-table :data="membershipFuncs" border style="width: 100%">
                        <el-table-column label="ID" prop="id" width="60"></el-table-column>
                        <el-table-column label="变量名称" prop="variable_name" width="150"></el-table-column>
                        <el-table-column label="模糊集" prop="fuzzy_set" width="120"></el-table-column>
                        <el-table-column label="梯形参数 [a,b,c,d]">
                            <template #default="scope">
                                {{ scope.row.parameters }}
                            </template>
                        </el-table-column>
                        <el-table-column label="有效范围" prop="valid_range"></el-table-column>
                    </el-table>
                </el-card>
            </div>
        </div>
    </el-config-provider>
</template>

<script>
import { ref, onMounted } from 'vue'
import util from '../../../util.js'
const { get } = util

export default {
    name: 'Ambiguous',
    setup() {
        const fuzzyRules = ref([])
        const membershipFuncs = ref([])

        const fetchData = async () => {
            try {
                const resFuzzy = await get('/api/knowledge/fuzzy')
                if (resFuzzy && resFuzzy.data && resFuzzy.data.data) {
                    fuzzyRules.value = resFuzzy.data.data
                } else if (resFuzzy && resFuzzy.data) {
                    fuzzyRules.value = resFuzzy.data
                }

                const resMember = await get('/api/knowledge/membership')
                if (resMember && resMember.data && resMember.data.data) {
                    membershipFuncs.value = resMember.data.data
                } else if (resMember && resMember.data) {
                    membershipFuncs.value = resMember.data
                }
            } catch (error) {
                console.error("获取模糊知识数据失败:", error)
            }
        }

        onMounted(() => {
            fetchData()
        })

        return { fuzzyRules, membershipFuncs }
    }
}
</script>
