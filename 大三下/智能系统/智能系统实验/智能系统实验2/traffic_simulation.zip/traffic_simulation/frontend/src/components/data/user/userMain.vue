<template>
    <el-config-provider :locale="locale">
        <el-container>
            <div class="col-12 mb-2">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center">
                    <h6 class="active h6 sub_menu_title">
                        <el-icon><User /></el-icon>
                        <span>用户管理</span>
                    </h6>
                </div>
            </div>
        </el-container>
        <div class="table-responsive">
            <div class="col-12">
                <el-card class="box-card">
                    <div v-if="pageInfo.type === 'search'" class="fs-8 mb-3 text-primary">
                        关键字"{{ pageInfo.keyword }}"的搜索记录共{{ pageInfo.count }}条
                    </div>
                    <el-row>
                        <el-col :span="12">
                            <el-input v-model="keyword" id="search-keyword" placeholder="请输入关键字">
                                <template #append>
                                    <el-button type="primary" @click="onSearchClickHandler">
                                        <el-icon><Search /></el-icon>
                                    </el-button>
                                    <!-- 清除按钮（当处于搜索状态时显示） -->
                                    <el-button v-if="pageInfo.type === 'search'" type="info" @click="onClearSearchHandler">
                                        <el-icon><CircleClose /></el-icon>
                                    </el-button>
                                </template>
                                
                            </el-input>
                        </el-col>
                        <el-col :span="12">
                            <div class="d-flex card-row-title-optDiv justify-content-end flex-grow-0">
                                <el-button class="me-3" type="primary" @click="onAddButtonClick">
                                    <el-icon><Plus /></el-icon>
                                    <span class="hidden-sm-and-down">新增用户</span>
                                </el-button>

                                <el-button class="me-3" type="primary" @click="onDeleteMutilButtonClick">
                                    <el-icon><Delete /></el-icon>
                                    <span class="hidden-sm-and-down">批量删除</span>
                                </el-button>
                            </div>
                        </el-col>
                    </el-row>
                    
                    <!-- 分页信息显示 -->
                    <!-- <div v-if="pageInfo.count > 0" class="mb-3 mt-3 text-muted fs-8">
                        显示第 {{ (pageInfo.pageIndex - 1) * pageInfo.pageSize + 1 }} 到 
                        {{ Math.min(pageInfo.pageIndex * pageInfo.pageSize, pageInfo.count) }} 条记录，
                        共 {{ pageInfo.count }} 条
                    </div> -->
                    
                    <div class="table-responsive pt-3 pb-3" id="table_container">
                        <el-table 
                            :data="pageInfo.entitys" 
                            border 
                            table-layout="auto" 
                            style="width: 100%" 
                            ref="multipleTableRef"
                            @selection-change="onSelectionChange"
                        >
                            <el-table-column type="selection" width="55" />
                            <el-table-column label="ID" prop="id" width="80"></el-table-column>
                            <el-table-column label="姓名" prop="name"></el-table-column>
                            <el-table-column label="学号" prop="student_id"></el-table-column>
                            <el-table-column label="操作" width="200" align="center" fixed="right">
                                <template #default="scope">
                                    <el-button size="small" type="primary" link
                                        @click="onEditButtonClick(scope.$index, scope.row)">
                                        <el-icon><EditPen /></el-icon>编辑
                                    </el-button>
                                    <el-button size="small" type="danger" link
                                        @click="onDeleteButtonClick(scope.$index, scope.row)">
                                        <el-icon><Delete /></el-icon>删除
                                    </el-button>
                                </template>
                            </el-table-column>
                        </el-table>
                    </div>
                    
                    <div class="d-flex flex-row mt-3" id="pagination">
                        <el-pagination 
                            v-model:current-page="pageInfo.pageIndex" 
                            v-model:page-size="pageInfo.pageSize"
                            :page-sizes="[10, 20, 30, 50, 100]" 
                            :background="true"
                            layout="total, sizes, prev, pager, next, jumper" 
                            :total="pageInfo.count"
                            @size-change="onPageSizeChangeHandler" 
                            @current-change="onCurrentPageChangHandler" 
                        />
                    </div>
                </el-card>
            </div>
        </div>
        
        <!-- 添加用户对话框 -->
        <el-dialog v-model="addDialogVisible" :title="dialog_title" width="30%">
            <el-form-item label="姓名">
                <el-input v-model="form.name" autocomplete="off" placeholder="请输入用户姓名" />
            </el-form-item>
            <el-form-item label="学号">
                <el-input v-model="form.student_id" autocomplete="off" placeholder="请输入学号" />
            </el-form-item>
            <template #footer>
                <div class="dialog-footer">
                    <el-button @click="addDialogVisible = false">取消</el-button>
                    <el-button type="primary" @click="onAddClickHandler">确认</el-button>
                </div>
            </template>
        </el-dialog>
        
        <!-- 编辑用户对话框 -->
        <el-dialog v-model="editDialogVisible" title="编辑用户" width="30%">
            <el-form :model="editForm" label-width="80px">
                <el-form-item label="用户ID"  v-show="false">
                    <el-input v-model="editForm.id" :disabled="true" />
                </el-form-item>
                <el-form-item label="姓名" required>
                    <el-input v-model="editForm.name" autocomplete="off" placeholder="请输入用户姓名" />
                </el-form-item>
                <el-form-item label="学号">
                    <el-input v-model="editForm.student_id" autocomplete="off" placeholder="请输入学号" />
                </el-form-item>
            </el-form>
            <template #footer>
                <div class="dialog-footer">
                    <el-button @click="editDialogVisible = false">取消</el-button>
                    <el-button type="primary" @click="onEditConfirmHandler">确认</el-button>
                </div>
            </template>
        </el-dialog>
    </el-config-provider>
</template>

<script>
import { reactive, ref, toRefs, onBeforeMount, onMounted, onUnmounted } from 'vue'
import util from '../../../util.js'
import { ElConfigProvider } from 'element-plus'
import { ElMessage, ElMessageBox } from 'element-plus'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'

const { get, post, put, delete: del } = util

export default {
    name: 'UserMain',
    components: {
        ElConfigProvider
    },
    setup(props) {
        console.log("props", props)
        console.log('1-开始创建组件-Table')
        
        // 响应式数据
        const keyword = ref("")
        const dialog_title = ref("添加")
        const locale = zhCn
        let optType = "add"
        const formLabelWidth = ref("100px")
        const addDialogVisible = ref(false)
        const editDialogVisible = ref(false)
        const multipleTableRef = ref()
        const selectedRows = ref([])

        const form = reactive({
            form: {
                name: "",
                student_id: ""
            }
        })

        const editForm = reactive({
            id: null,
            name: "",
            student_id: ""
        })

        const pageInfo = reactive({
            pageInfo: {
                type: 'query',
                keyword: '',
                pageIndex: 1,
                pageSize: 20,
                count: 0,
                totalPages: 0,
                entitys: []
            }
        })
        
        // 方法
        async function onSearchClickHandler(event) {
            const searchKeyword = keyword.value;
            if (searchKeyword === '') {
                ElMessageBox.alert('请输入关键字', '警告', {
                    confirmButtonText: '确定',
                })
            } else {
                pageInfo.pageInfo.pageIndex = 1;
                pageInfo.pageInfo.type = "search";
                pageInfo.pageInfo.keyword = searchKeyword;
                
                const params = {
                    "findType": "search",
                    "keyword": searchKeyword,
                    "page": 1,
                    "size": pageInfo.pageInfo.pageSize
                }
                await requestList(params);
            }
        }

        async function onClearSearchHandler() {
            // 重置搜索关键字
            keyword.value = "";
            
            // 重置分页信息
            pageInfo.pageInfo.type = "query";
            pageInfo.pageInfo.keyword = "";
            pageInfo.pageInfo.pageIndex = 1;  // 重置到第一页
            
            // 重新加载数据
            await initData();
            
            // 可选：显示清除成功的提示
            ElMessage({
                message: '搜索已清除，显示所有用户',
                type: 'info',
                duration: 2000
            })
        }

        async function onPageSizeChangeHandler(pageSize) {
            pageInfo.pageInfo.pageSize = pageSize;
            pageInfo.pageInfo.pageIndex = 1;
            
            const params = {
                "findType": pageInfo.pageInfo.type,
                "page": 1,
                "size": pageSize
            }
            
            if (pageInfo.pageInfo.type === "search" && pageInfo.pageInfo.keyword) {
                params.keyword = pageInfo.pageInfo.keyword;
            }
            
            await requestList(params);
        }

        async function onCurrentPageChangHandler(page) {
            pageInfo.pageInfo.pageIndex = page;
            
            const params = {
                "findType": pageInfo.pageInfo.type,
                "page": page,
                "size": pageInfo.pageInfo.pageSize
            }
            
            if (pageInfo.pageInfo.type === "search" && pageInfo.pageInfo.keyword) {
                params.keyword = pageInfo.pageInfo.keyword;
            }
            
            await requestList(params);
        }

        function onAddButtonClick() {
            optType = "add"
            dialog_title.value = "添加用户"
            form.form.name = "" // 清空表单
            form.form.student_id = "" 
            addDialogVisible.value = true
        }

        async function onAddClickHandler() {
            if (!form.form.name.trim()) {
                ElMessage({
                    message: '请输入用户姓名',
                    type: 'warning',
                    duration: 2000
                })
                return
            }
            
            try {
                const url = "/api/users/"
                const user = { name: form.form.name.trim(), student_id: form.form.student_id.trim() }
                const res = await post(url, user)
                
                ElMessage({
                    message: '用户添加成功',
                    type: 'success',
                    duration: 2000
                })
                
                addDialogVisible.value = false
                await initData()
            } catch (error) {
                console.error('添加用户失败:', error)
            }
        }

        async function onEditButtonClick(index, row) {
            optType = "edit"
            dialog_title.value = "编辑用户"
            editForm.id = row.id
            editForm.name = row.name
            editForm.student_id = row.student_id || ""
            editDialogVisible.value = true
        }

        async function onEditConfirmHandler() {
            if (!editForm.id || !editForm.name.trim()) {
                ElMessage({
                    message: '请输入用户姓名',
                    type: 'warning',
                    duration: 2000
                })
                return
            }
            
            try {
                const url = `/api/users/${editForm.id}`
                const user = { name: editForm.name.trim(), student_id: editForm.student_id.trim() }
                const res = await put(url, user)
                
                ElMessage({
                    message: '用户更新成功',
                    type: 'success',
                    duration: 2000
                })
                
                editDialogVisible.value = false
                await initData()
            } catch (error) {
                console.error('编辑用户失败:', error)
            }
        }

        async function onDeleteButtonClick(index, row) {
            try {
                await ElMessageBox.confirm(
                    `确定要删除用户 "${row.name}" 吗？`,
                    '确认删除',
                    {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                    }
                )
                
                const url = `/api/users/${row.id}`
                const res = await del(url)
                
                ElMessage({
                    message: '删除成功',
                    type: 'success',
                    duration: 2000
                })
                
                if (pageInfo.pageInfo.entitys.length === 1 && pageInfo.pageInfo.pageIndex > 1) {
                    pageInfo.pageInfo.pageIndex--
                }
                
                await initData()
            } catch (error) {
                if (error !== 'cancel') {
                    console.error('删除用户失败:', error)
                }
            }
        }

        function onSelectionChange(val) {
            selectedRows.value = val
        }

        async function onDeleteMutilButtonClick() {
            if (selectedRows.value.length === 0) {
                ElMessage({
                    message: '请至少选择一条记录',
                    type: 'warning',
                    duration: 2000
                })
                return
            }
            
            try {
                const confirmMessage = `确定要删除选中的 ${selectedRows.value.length} 条记录吗？`
                
                await ElMessageBox.confirm(
                    confirmMessage,
                    '确认批量删除',
                    {
                        confirmButtonText: '确定',
                        cancelButtonText: '取消',
                        type: 'warning',
                    }
                )
                
                const deletePromises = selectedRows.value.map(row => {
                    const url = `/api/users/${row.id}`
                    return del(url)
                })
                
                await Promise.all(deletePromises)
                
                ElMessage({
                    message: `成功删除 ${selectedRows.value.length} 条记录`,
                    type: 'success',
                    duration: 2000
                })
                
                selectedRows.value = []
                if (multipleTableRef.value) {
                    multipleTableRef.value.clearSelection()
                }
                
                if (pageInfo.pageInfo.entitys.length === 0 && pageInfo.pageInfo.pageIndex > 1) {
                    pageInfo.pageInfo.pageIndex--
                }
                
                await initData()
            } catch (error) {
                if (error !== 'cancel') {
                    console.error('批量删除失败:', error)
                }
            }
        }

        async function requestList(params) {
            const queryParams = {
                skip: (params.page - 1) * params.size,
                limit: params.size
            }
            
            var url = "/api/users/"
            
            if (params.findType === "search") {
                url = `/api/users/search/${encodeURIComponent(params.keyword)}`
            }
            
            try {
                var res = await get(url, queryParams)
                const resData = res.data;
                
                pageInfo.pageInfo.entitys = resData.items || [];
                pageInfo.pageInfo.count = resData.total || 0;
                pageInfo.pageInfo.totalPages = resData.pages || 1;
                pageInfo.pageInfo.pageIndex = resData.page || 1;
                pageInfo.pageInfo.pageSize = resData.size || params.size;
                pageInfo.pageInfo.type = params.findType || "query";
                
                if (params.keyword) {
                    pageInfo.pageInfo.keyword = params.keyword;
                }
                
                console.log("分页数据:", pageInfo.pageInfo)
            } catch (error) {
                console.error("获取数据失败:", error)
                pageInfo.pageInfo.entitys = [];
                pageInfo.pageInfo.count = 0;
                pageInfo.pageInfo.totalPages = 0;
            }
        }

        async function initData() {
            const pageSize = pageInfo.pageInfo.pageSize || 20;
            const pageIndex = pageInfo.pageInfo.pageIndex || 1;
            
            const params = {
                "findType": pageInfo.pageInfo.type,
                "page": pageIndex,
                "size": pageSize
            }
            
            if (pageInfo.pageInfo.type === "search" && pageInfo.pageInfo.keyword) {
                params.keyword = pageInfo.pageInfo.keyword;
            }
            
            await requestList(params);
        }

        onBeforeMount(() => {
            console.log('2.组件挂载页面之前执行----onBeforeMount')
        })

        onMounted(async () => {
            console.log('3.-组件挂载到页面之后执行-------onMounted')
            await initData();
        })

        onUnmounted(() => {
            console.log("table un Mounted")
        })

        return {
            ...toRefs(pageInfo), 
            ...toRefs(form),
            editForm,
            formLabelWidth, 
            keyword, 
            addDialogVisible,
            editDialogVisible,
            dialog_title, 
            multipleTableRef,
            locale,
            onSearchClickHandler, 
            onClearSearchHandler,
            onPageSizeChangeHandler,
            onCurrentPageChangHandler, 
            onAddButtonClick, 
            onAddClickHandler,  
            onEditButtonClick,
            onEditConfirmHandler,
            onDeleteButtonClick,
            onSelectionChange,
            onDeleteMutilButtonClick
        }
    },
}
</script>

<style scoped>
/* 可以根据需要添加样式 */
</style>