import axios from 'axios'
import { ElMessage, ElLoading } from 'element-plus'

// 封装统一的错误处理函数
const handleRequestError = (error, loading) => {
    loading.close()
    
    let errorMessage = '请求失败，请稍后重试'
    
    if (error.response) {
        // 服务器返回了错误状态码
        const status = error.response.status
        const data = error.response.data
        
        switch (status) {
            case 400:
                errorMessage = data.detail || '请求参数错误'
                break
            case 401:
                errorMessage = '未授权，请重新登录'
                // 可以在这里添加跳转到登录页的逻辑
                break
            case 403:
                errorMessage = '禁止访问'
                break
            case 404:
                errorMessage = '请求的资源不存在'
                break
            case 500:
                errorMessage = '服务器内部错误'
                break
            case 502:
                errorMessage = '网关错误'
                break
            case 503:
                errorMessage = '服务不可用'
                break
            default:
                errorMessage = data?.detail || `请求错误 (${status})`
        }
    } else if (error.request) {
        // 请求已发送但没有收到响应
        errorMessage = '网络连接异常，请检查网络'
    } else {
        // 请求配置出错
        errorMessage = error.message || '请求配置错误'
    }
    
    // 显示错误提示
    ElMessage({
        message: errorMessage,
        type: 'error',
        duration: 3000
    })
    
    console.error('请求错误:', error)
    throw error // 继续抛出错误，以便调用方可以进一步处理
}

const post = async function(url, entity) {
    const loading = ElLoading.service({
        lock: true,
        text: 'Loading',
        background: 'rgba(0, 0, 0, 0.7)',
    })
    
    try {
        var res = await axios.post(url, entity)
        loading.close()
        return res
    } catch (error) {
        handleRequestError(error, loading)
    }
}

const get = async function(url, params = {}) {
    const loading = ElLoading.service({
        lock: true,
        text: 'Loading',
        background: 'rgba(0, 0, 0, 0.7)',
    })
    
    try {
        var res = await axios.get(url, { params })
        loading.close()
        return res
    } catch (error) {
        handleRequestError(error, loading)
    }
}

const put = async function(url, entity) {
    const loading = ElLoading.service({
        lock: true,
        text: 'Loading',
        background: 'rgba(0, 0, 0, 0.7)',
    })
    
    try {
        var res = await axios.put(url, entity)
        loading.close()
        return res
    } catch (error) {
        handleRequestError(error, loading)
    }
}

const del = async function(url, data = {}) {
    const loading = ElLoading.service({
        lock: true,
        text: 'Loading',
        background: 'rgba(0, 0, 0, 0.7)',
    })
    
    try {
        var res = await axios.delete(url, { data })
        loading.close()
        return res
    } catch (error) {
        handleRequestError(error, loading)
    }
}

// 导出所有方法
export default { post, get, put, delete: del }