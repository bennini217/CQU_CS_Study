
import { createRouter, createWebHistory, createWebHashHistory } from 'vue-router'

const Dashboard = () => import("../components/dashboard")
const HelloWorld = () => import("../components/HelloWorld")
const Home = () => import("../components/data/home")

const Main = () => import("../components/layout/main")

const UserMain = () => import("../components/data/user/userMain")


const CarMain = () => import("../components/data/car/carMain")
const Trustworthy = () => import("../components/data/knowledge/trustworthy")
const Ambiguous = () => import("../components/data/knowledge/ambiguous")

const routes = [

  {
    path: "/",
    meta: {
      menu: true,
      name: "主页",
      icon: "home",
      type: "0"  // 菜单类型
    },
    component: Dashboard,
    children: [
      {
        name: "home",
        path: '',
        component: Home,
        meta: {
          menu: false  // 不在菜单显示
        }
      }
    ]
  },

  {
    path: "/preview",
    component: HelloWorld,
    meta: {
      menu: true,
      name: "仿真系统",
      icon: "home",
      type: "0"  // 菜单类型
    }
  },

  {
    path: "/database",
    component: Dashboard,
    meta: {
      menu: true,
      name: "数据库",
      icon: "home",
      type: "0"  // 菜单类型
    },

    children: [
      {
        name: 'user',
        path: '/user', 
        component: UserMain, 
        meta: {
          menu: true,
          name: "用户管理",
          icon: "home",
          type: "0"  // 菜单类型
        },
        props: true
      },
      { 
        name: 'car', 
        path: '/car', 
        component: CarMain, 
        meta: {
          menu: true,
          name: "车流量管理",
          icon: "home",
          type: "0"  // 菜单类型
        },

        props: true 
      },
    ]
  },

  {
    path: "/knowledge",
    component: Dashboard,
    meta: {
      menu: true,
      name: "知识库",
      icon: "home",
      type: "0"  // 菜单类型
    },

    children: [
      {
        name: 'trustworthy',
        path: '/trustworthy',
        component: Trustworthy,
        meta: {
          menu: true,
          name: "可信知识管理",
          icon: "home",
          type: "0"  // 菜单类型
        },
        props: true
      }, {
        name: 'ambiguous',
        path: '/ambiguous',
        component: Ambiguous,
        meta: {
          menu: true,
          name: "模糊知识管理",
          icon: "home",
          type: "0"  // 菜单类型
        },
        props: true
      },
    ]

  }
]

export default createRouter({
  history: createWebHistory(),
  routes: routes
})