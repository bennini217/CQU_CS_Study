from sqlalchemy.orm import Session
from app.models.knowledge import CredibilityKnowledge, MembershipFunction, FuzzyKnowledge

class KnowledgeDAO:
    """
    知识库 DAO 层，处理可信度知识、模糊知识、隶属函数的 CRUD
    """
    
    # === 可信度知识 (Credibility) ===
    @staticmethod
    def get_credibility_rules(db: Session, skip: int = 0, limit: int = 100):
        return db.query(CredibilityKnowledge).offset(skip).limit(limit).all()

    @staticmethod
    def create_credibility_rule(db: Session, rule_data: dict):
        db_rule = CredibilityKnowledge(**rule_data)
        db.add(db_rule)
        db.commit()
        db.refresh(db_rule)
        return db_rule

    @staticmethod
    def delete_credibility_rule(db: Session, rule_id: int):
        rule = db.query(CredibilityKnowledge).filter(CredibilityKnowledge.rule_id == rule_id).first()
        if rule:
            db.delete(rule)
            db.commit()
            return True
        return False

    # === 隶属函数 (Membership Function) ===
    @staticmethod
    def get_membership_functions(db: Session, skip: int = 0, limit: int = 100):
        return db.query(MembershipFunction).offset(skip).limit(limit).all()

    @staticmethod
    def create_membership_function(db: Session, func_data: dict):
        db_func = MembershipFunction(**func_data)
        db.add(db_func)
        db.commit()
        db.refresh(db_func)
        return db_func

    # === 模糊知识规则 (Fuzzy Knowledge) ===
    @staticmethod
    def get_fuzzy_rules(db: Session, skip: int = 0, limit: int = 100):
        return db.query(FuzzyKnowledge).offset(skip).limit(limit).all()

    @staticmethod
    def create_fuzzy_rule(db: Session, rule_data: dict):
        db_rule = FuzzyKnowledge(**rule_data)
        db.add(db_rule)
        db.commit()
        db.refresh(db_rule)
        return db_rule

    @staticmethod
    def delete_fuzzy_rule(db: Session, rule_id: int):
        rule = db.query(FuzzyKnowledge).filter(FuzzyKnowledge.rule_id == rule_id).first()
        if rule:
            db.delete(rule)
            db.commit()
            return True
        return False

knowledge_dao = KnowledgeDAO()
