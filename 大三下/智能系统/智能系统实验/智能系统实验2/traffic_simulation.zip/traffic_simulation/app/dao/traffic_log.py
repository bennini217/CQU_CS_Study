from sqlalchemy.orm import Session
from app.models.traffic_log import TrafficLog

class TrafficLogDAO:
    """
    TrafficLog 数据库操作层 (DAO)
    负责处理与车流量日志表相关的增删改查操作。
    """

    @staticmethod
    def create_log(
        db: Session, 
        car_info: list, 
        light_times: list, 
        sensor_triggered: int = 0,
        intersection_id: str = "intersection_01",
        data_source: str = "frontend_sim"
    ) -> TrafficLog:
        """
        将一轮新的车流量数据（输入）和绿灯时长数据（输出）写入数据库。
        
        car_info: [{'id': 0, 'carNumber': x}, ...]
        light_times: [ns_l_time, ns_sr_time, ew_l_time, ew_sr_time]
        """
        # 解析车流量列表
        # 按照前端逻辑: 0=南北左转, 1=南北直右, 2=东西左转, 3=东西直右
        cars = {item['id']: item['carNumber'] for item in car_info}
        
        new_log = TrafficLog(
            intersection_id=intersection_id,
            data_source=data_source,
            sensor_triggered=sensor_triggered,
            
            # 记录下位机/前端传来的车流量
            ns_l_cars=cars.get(0, 0),
            ns_sr_cars=cars.get(1, 0),
            ew_l_cars=cars.get(2, 0),
            ew_sr_cars=cars.get(3, 0),
            
            # 记录上位机推理算出的绿灯时长
            ns_l_time=light_times[0],
            ns_sr_time=light_times[1],
            ew_l_time=light_times[2],
            ew_sr_time=light_times[3]
        )
        
        db.add(new_log)
        db.commit()
        db.refresh(new_log)
        
        return new_log

    @staticmethod
    def get_logs(db: Session, skip: int = 0, limit: int = 100):
        """
        分页查询车流量日志，按时间倒序排列（最新的在前面）
        """
        return db.query(TrafficLog).order_by(TrafficLog.timestamp.desc()).offset(skip).limit(limit).all()

traffic_log_dao = TrafficLogDAO()
