import logging
from app.database import SessionLocal
from app.models.knowledge import MembershipFunction, FuzzyKnowledge

logger = logging.getLogger(__name__)

class ReasonService:
    def __init__(self):
        pass

    def _trapezoidal_membership(self, x, params):
        """
        计算梯形/三角形隶属度
        params: [a, b, c, d]
        """
        if len(params) != 4:
            return 0.0
        a, b, c, d = params
        if x <= a or x >= d:
            return 0.0
        elif a < x < b:
            return (x - a) / (b - a + 1e-9)
        elif b <= x <= c:
            return 1.0
        elif c < x < d:
            return (d - x) / (d - c + 1e-9)
        return 0.0

    def reason_process(self, carInfos):
        """
        核心模糊控制推理机 (实验二 模糊矩阵计算)
        carInfos: [{'id': 0, 'carNumber': 2}, ...]
        0:南北左转, 1:南北直右, 2:东西左转, 3:东西直右
        """
        logger.info(f"=== 开始模糊推理 === 车流量信息：{carInfos}")

        # 1. 提取各方向车流量
        cars = {item['id']: item['carNumber'] for item in carInfos}
        car_ns = cars.get(0, 0) + cars.get(1, 0)  # 南北总车流
        car_ew = cars.get(2, 0) + cars.get(3, 0)  # 东西总车流
        logger.info(f"南北总车流: {car_ns}, 东西总车流: {car_ew}")

        db = SessionLocal()
        try:
            # 2. 读取数据库中的隶属函数
            mf_records = db.query(MembershipFunction).all()
            car_mfs = {mf.fuzzy_set: mf.parameters for mf in mf_records if mf.variable_name == "car_count"}
            time_mfs = {mf.fuzzy_set: mf.parameters for mf in mf_records if mf.variable_name == "light_time"}

            # 3. 模糊化 (Fuzzification)
            ns_fuzzy = {k: self._trapezoidal_membership(car_ns, v) for k, v in car_mfs.items()}
            ew_fuzzy = {k: self._trapezoidal_membership(car_ew, v) for k, v in car_mfs.items()}
            logger.info(f"模糊化结果 - 南北: {ns_fuzzy}")
            logger.info(f"模糊化结果 - 东西: {ew_fuzzy}")

            # 4. 模糊规则匹配 (Fuzzy Inference)
            rules = db.query(FuzzyKnowledge).all()
            
            # 记录每个控制方向上，各个输出模糊集("短","中","长")的最大激活度
            # 例如: activation['ns_l']['长'] = 0.6
            activation = {
                'ns_l': {}, 'ns_sr': {}, 'ew_l': {}, 'ew_sr': {}
            }
            for d in activation:
                for k in time_mfs.keys():
                    activation[d][k] = 0.0

            for rule in rules:
                # 计算前提条件的激活度 (取 min)
                ns_degree = ns_fuzzy.get(rule.condition_ns, 0)
                ew_degree = ew_fuzzy.get(rule.condition_ew, 0)
                rule_degree = min(ns_degree, ew_degree) * rule.weight

                if rule_degree > 0 and rule.target_direction in activation:
                    # 取 max (Mamdani 聚合)
                    current_val = activation[rule.target_direction].get(rule.result_time, 0)
                    activation[rule.target_direction][rule.result_time] = max(current_val, rule_degree)
                    logger.info(f"触发规则 [{rule.rule_name}]: 激活度={rule_degree:.2f} -> {rule.target_direction}设为{rule.result_time}")

            # 5. 解模糊化 (Defuzzification - 重心法 Centroid)
            light_times = [10, 10, 10, 10] # 默认基础时间 10秒
            direction_map = {'ns_l': 0, 'ns_sr': 1, 'ew_l': 2, 'ew_sr': 3}
            
            # 我们在 10~60 秒的范围内进行离散积分
            y_range = range(10, 61)

            for target_dir, degree_map in activation.items():
                numerator = 0.0
                denominator = 0.0
                
                for y in y_range:
                    # 在该输出点 y 处，所有模糊集的最大隶属度
                    max_mu = 0.0
                    for fuzzy_set, degree in degree_map.items():
                        if degree > 0 and fuzzy_set in time_mfs:
                            # 截断法: min(规则激活度, 该点本身的隶属度)
                            mu_y = self._trapezoidal_membership(y, time_mfs[fuzzy_set])
                            mu_y_truncated = min(degree, mu_y)
                            max_mu = max(max_mu, mu_y_truncated)
                    
                    numerator += y * max_mu
                    denominator += max_mu
                
                if denominator > 0:
                    calculated_time = int(round(numerator / denominator))
                    idx = direction_map[target_dir]
                    light_times[idx] = calculated_time
                    logger.info(f"{target_dir} 解模糊化结果: {calculated_time} 秒")
                else:
                    # 如果没有任何规则触发，使用默认保底逻辑
                    idx = direction_map[target_dir]
                    light_times[idx] = 10 + int(cars.get(idx, 0) * 1.5) # 简单保底：一辆车加1.5秒
                    logger.info(f"{target_dir} 无模糊规则触发，使用保底时长: {light_times[idx]} 秒")

            logger.info(f"=== 推理结束 === 最终红绿灯时长: {light_times}")
            return light_times

        except Exception as e:
            logger.error(f"模糊推理发生异常: {e}")
            return [10, 10, 10, 10]
        finally:
            db.close()

reason_service = ReasonService()
