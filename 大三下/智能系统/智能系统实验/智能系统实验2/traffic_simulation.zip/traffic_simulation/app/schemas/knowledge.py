from pydantic import BaseModel
from typing import List, Optional

# === 可信度知识 Schemas ===
class CredibilityCreate(BaseModel):
    rule_name: str
    rule_type: str = "CF"
    premise_target: str
    premise_condition: str
    conclusion_target: str
    conclusion_action: str
    cf_value: float

class CredibilityResponse(CredibilityCreate):
    rule_id: int
    class Config:
        from_attributes = True

# === 隶属函数 Schemas ===
class MembershipCreate(BaseModel):
    variable_name: str
    fuzzy_set: str
    parameters: List[float]
    valid_range: Optional[str] = None

class MembershipResponse(MembershipCreate):
    id: int
    class Config:
        from_attributes = True

# === 模糊知识 Schemas ===
class FuzzyRuleCreate(BaseModel):
    rule_name: str
    condition_ns: str
    condition_ew: str
    target_direction: str
    result_time: str
    weight: float = 1.0
    description: Optional[str] = None

class FuzzyRuleResponse(FuzzyRuleCreate):
    rule_id: int
    class Config:
        from_attributes = True
