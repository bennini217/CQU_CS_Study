from fastapi import APIRouter, Depends, HTTPException
from fastapi.encoders import jsonable_encoder
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.dao.knowledge import knowledge_dao
from app.schemas.knowledge import (
    CredibilityCreate, CredibilityResponse,
    MembershipCreate, MembershipResponse,
    FuzzyRuleCreate, FuzzyRuleResponse
)

router = APIRouter(prefix="/api/knowledge", tags=["知识库管理"])

# ==========================================
# 可信度知识 (Credibility Knowledge)
# ==========================================
@router.get("/credibility")
def get_credibility_rules(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    rules = knowledge_dao.get_credibility_rules(db, skip, limit)
    return {"code": 200, "message": "获取成功", "data": jsonable_encoder(rules)}

@router.post("/credibility")
def create_credibility_rule(rule: CredibilityCreate, db: Session = Depends(get_db)):
    try:
        new_rule = knowledge_dao.create_credibility_rule(db, rule.model_dump())
        return {"code": 200, "message": "创建成功", "data": new_rule}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.delete("/credibility/{rule_id}")
def delete_credibility_rule(rule_id: int, db: Session = Depends(get_db)):
    success = knowledge_dao.delete_credibility_rule(db, rule_id)
    if not success:
        raise HTTPException(status_code=404, detail="规则不存在")
    return {"code": 200, "message": "删除成功"}

# ==========================================
# 模糊知识规则 (Fuzzy Rules)
# ==========================================
@router.get("/fuzzy")
def get_fuzzy_rules(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    rules = knowledge_dao.get_fuzzy_rules(db, skip, limit)
    return {"code": 200, "message": "获取成功", "data": jsonable_encoder(rules)}

@router.post("/fuzzy")
def create_fuzzy_rule(rule: FuzzyRuleCreate, db: Session = Depends(get_db)):
    try:
        new_rule = knowledge_dao.create_fuzzy_rule(db, rule.model_dump())
        return {"code": 200, "message": "创建成功", "data": new_rule}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.delete("/fuzzy/{rule_id}")
def delete_fuzzy_rule(rule_id: int, db: Session = Depends(get_db)):
    success = knowledge_dao.delete_fuzzy_rule(db, rule_id)
    if not success:
        raise HTTPException(status_code=404, detail="规则不存在")
    return {"code": 200, "message": "删除成功"}

# ==========================================
# 隶属函数 (Membership Functions)
# ==========================================
@router.get("/membership")
def get_membership_functions(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    funcs = knowledge_dao.get_membership_functions(db, skip, limit)
    return {"code": 200, "message": "获取成功", "data": jsonable_encoder(funcs)}

@router.post("/membership")
def create_membership_function(func: MembershipCreate, db: Session = Depends(get_db)):
    try:
        new_func = knowledge_dao.create_membership_function(db, func.model_dump())
        return {"code": 200, "message": "创建成功", "data": new_func}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
