from fastapi.encoders import jsonable_encoder
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.dao.traffic_log import traffic_log_dao

router = APIRouter(prefix="/api/traffic_logs", tags=["车流量日志管理"])

@router.get("/")
def get_traffic_logs(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """
    获取车流量日志列表（分页，按时间倒序）
    """
    logs = traffic_log_dao.get_logs(db, skip=skip, limit=limit)
    return {
        "code": 200,
        "message": "获取成功",
        "data": jsonable_encoder(logs)
    }
