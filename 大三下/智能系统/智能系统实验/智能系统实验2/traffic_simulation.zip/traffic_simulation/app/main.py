# app/run.py
import asyncio

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging
from contextlib import asynccontextmanager

# 导入路由
from app.routers import user, websocket, traffic_log, knowledge
from app.middleware import DBSessionMiddleware, WebSocketCORSMiddleware
from app.database import engine, Base

# 注册所有模型以便 SQLAlchemy 能够发现并建表
from app.models.user import User
from app.models.traffic_log import TrafficLog
from app.models.knowledge import CredibilityKnowledge, MembershipFunction, FuzzyKnowledge

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    应用生命周期管理
    """
    # 启动时创建数据库表
    logger.info("创建数据库表...")
    Base.metadata.create_all(bind=engine)
    logger.info("数据库表创建完成")

    # 导入并启动定时任务
    from app.routers.websocket import send_periodic_updates
    task = asyncio.create_task(send_periodic_updates())
    logger.info("定时任务已启动")

    yield

    task.cancel()  # 取消定时任务
    try:
        await task
    except asyncio.CancelledError:
        pass
    logger.info("定时任务已取消")

    # 关闭时清理资源
    logger.info("应用关闭，清理资源...")


# 创建FastAPI应用
app = FastAPI(
    title="交通信号灯控制系统API",
    description="基于FastAPI的三层架构Demo，包含数据库操作和WebSocket功能",
    version="1.0.0",
    lifespan=lifespan
)

# 添加中间件
# app.add_middleware(WebSocketCORSMiddleware)
app.add_middleware(DBSessionMiddleware)
# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应限制域名
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "WebSocket"],
    allow_headers=["*"],
    allow_origin_regex=".*",  # 正则表达式匹配所有
    expose_headers=["*"]
)

# 注册路由
app.include_router(user.router)
app.include_router(websocket.router)
app.include_router(traffic_log.router)
app.include_router(knowledge.router)


@app.get("/")
async def root():
    """
    根端点
    """
    return {
        "message": "交通信号灯控制系统API",
        "version": "1.0.0",
        "endpoints": {
            "users": "/users",
            "websocket": "/ws/chat",
            "docs": "/docs",
            "redoc": "/redoc"
        }
    }


@app.get("/health")
async def health_check():
    """
    健康检查端点
    """
    return {
        "status": "healthy",
        "timestamp": "2024-01-01T00:00:00Z"
    }




if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="debug"
    )