from sqlalchemy import Column, Integer, String, Float, JSON
from app.database import Base

class CredibilityKnowledge(Base):
    """
    可信度知识模型 (CF)
    用于处理带有不确定性的确切规则。
    例如：如果传感器触发，则南北左转车流大概率会增加。
    """
    __tablename__ = "credibility_knowledge"

    rule_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    rule_name = Column(String(50), nullable=False, unique=True, comment="规则名称")
    rule_type = Column(String(20), default="CF", comment="规则类型: CF(可信度)")
    
    # 前提条件拆分
    premise_target = Column(String(50), nullable=False, comment="前提目标 (如: 避障传感器)")
    premise_condition = Column(String(50), nullable=False, comment="前提状态 (如: == TRIGGERED)")
    
    # 结论动作拆分
    conclusion_target = Column(String(50), nullable=False, comment="结论目标 (如: 东西直行车流)")
    conclusion_action = Column(String(50), nullable=False, comment="结论动作 (如: INCREASE)")
    
    # 权重与可信度
    cf_value = Column(Float, nullable=False, comment="规则自身的可信度因子 CF (0~1)")

    def __repr__(self):
        return f"<CredibilityKnowledge(id={self.rule_id}, name={self.rule_name})>"


class MembershipFunction(Base):
    """
    隶属函数参数表
    存储模糊集(如"大","中","小")的具体数学参数。
    支持梯形或三角形隶属函数。
    """
    __tablename__ = "membership_functions"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    variable_name = Column(String(50), nullable=False, comment="变量名称 (如: car_count, light_time)")
    fuzzy_set = Column(String(20), nullable=False, comment="模糊集名称 (如: 小, 中, 大, 短, 长)")
    
    # 使用 JSON 存储参数，例如梯形函数需要4个点 [a, b, c, d]，三角形需要3个点 [a, b, c]
    parameters = Column(JSON, nullable=False, comment="隶属函数参数 (JSON格式数组)")
    
    valid_range = Column(String(50), comment="有效范围描述 (如: 0~50辆)")

    def __repr__(self):
        return f"<MembershipFunction(var={self.variable_name}, set={self.fuzzy_set})>"


class FuzzyKnowledge(Base):
    """
    模糊规则知识模型
    存储模糊控制推理矩阵。
    """
    __tablename__ = "fuzzy_knowledge"

    rule_id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    rule_name = Column(String(50), nullable=False, unique=True, comment="规则名称")
    
    # 模糊规则的前提条件（对应 MembershipFunction 中的 fuzzy_set）
    condition_ns = Column(String(20), nullable=False, comment="南北向车流量模糊集 (小/中/大)")
    condition_ew = Column(String(20), nullable=False, comment="东西向车流量模糊集 (小/中/大)")
    
    # 结论与指向（明确指出改变的是哪个方向的灯）
    target_direction = Column(String(50), nullable=False, comment="目标控制方向 (如: ns_l, ns_sr, ew_l, ew_sr)")
    result_time = Column(String(20), nullable=False, comment="输出时长模糊集 (短/中/长)")
    
    weight = Column(Float, default=1.0, comment="该条模糊规则的权重系数 (0~1)")
    description = Column(String(255), comment="规则自然语言描述")

    def __repr__(self):
        return f"<FuzzyKnowledge(id={self.rule_id}, target={self.target_direction})>"
