from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.sql import func
from app.database import Base

class TrafficLog(Base):
    """
    车流量与信号灯日志模型
    存储下位机(或前端)上传的传感器/车流数据，以及上位机(推理机)输出的绿灯时长。
    """
    __tablename__ = "traffic_logs"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    
    # 扩展性设计
    intersection_id = Column(String(50), default="intersection_01", comment="路口ID，便于多路口扩展")
    data_source = Column(String(20), default="frontend_sim", comment="数据来源: frontend_sim(前端仿真) 或 hardware_sensor(下位机传感器)")
    
    # 记录时间
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), comment="记录时间")

    # === 下位机/前端输入数据 ===
    # 这些是推理的前提（输入）
    ns_l_cars = Column(Integer, default=0, comment="南北左转车辆数")
    ns_sr_cars = Column(Integer, default=0, comment="南北直行右转车辆数")
    ew_l_cars = Column(Integer, default=0, comment="东西左转车辆数")
    ew_sr_cars = Column(Integer, default=0, comment="东西直行右转车辆数")
    sensor_triggered = Column(Integer, default=0, comment="传感器是否被遮挡触发(1是0否)")

    # === 上位机输出数据 ===
    # 这些是推理的结果（输出）
    ns_l_time = Column(Integer, default=0, comment="南北左转绿灯时长")
    ns_sr_time = Column(Integer, default=0, comment="南北直行右转绿灯时长")
    ew_l_time = Column(Integer, default=0, comment="东西左转绿灯时长")
    ew_sr_time = Column(Integer, default=0, comment="东西直行右转绿灯时长")

    def __repr__(self):
        return f"<TrafficLog(id={self.id}, intersection={self.intersection_id}, time={self.timestamp})>"
