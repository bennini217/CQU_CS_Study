import json
from sqlalchemy.orm import Session
from app.database import SessionLocal, engine, Base
from app.models.knowledge import CredibilityKnowledge, MembershipFunction, FuzzyKnowledge

def init_knowledge_base():
    """
    初始化实验二要求的知识库数据
    """
    print("开始初始化知识库数据...")
    db: Session = SessionLocal()
    
    try:
        # 清空旧数据（防止重复运行脚本报错）
        db.query(CredibilityKnowledge).delete()
        db.query(MembershipFunction).delete()
        db.query(FuzzyKnowledge).delete()
        db.commit()

        # ==========================================
        # 1. 插入可信度知识 (不少于3条)
        # ==========================================
        cf_rules = [
            CredibilityKnowledge(
                rule_name="传感器遮挡->车流激增",
                premise_target="sensor",
                premise_condition="TRIGGERED",
                conclusion_target="car_flow_status",
                conclusion_action="SURGE",
                cf_value=0.85
            ),
            CredibilityKnowledge(
                rule_name="车流激增->发生拥堵",
                premise_target="car_count_difference",
                premise_condition=">10",
                conclusion_target="traffic_jam",
                conclusion_action="TRUE",
                cf_value=0.90
            ),
            CredibilityKnowledge(
                rule_name="发生拥堵->增加绿灯时长",
                premise_target="traffic_jam",
                premise_condition="TRUE",
                conclusion_target="light_time_bonus",
                conclusion_action="+15",
                cf_value=0.80
            )
        ]
        db.add_all(cf_rules)
        print("已插入 3 条可信度规则。")

        # ==========================================
        # 2. 插入隶属函数参数 (梯形/三角形)
        # ==========================================
        membership_funcs = [
            # 车流量 (car_count)
            MembershipFunction(variable_name="car_count", fuzzy_set="小", parameters=[0, 0, 5, 10], valid_range="0~50辆"),
            MembershipFunction(variable_name="car_count", fuzzy_set="中", parameters=[5, 12, 18, 25], valid_range="0~50辆"),
            MembershipFunction(variable_name="car_count", fuzzy_set="大", parameters=[20, 30, 50, 50], valid_range="0~50辆"),
            
            # 绿灯时长 (light_time)
            MembershipFunction(variable_name="light_time", fuzzy_set="短", parameters=[10, 10, 20, 30], valid_range="10~60秒"),
            MembershipFunction(variable_name="light_time", fuzzy_set="中", parameters=[20, 30, 40, 50], valid_range="10~60秒"),
            MembershipFunction(variable_name="light_time", fuzzy_set="长", parameters=[40, 50, 60, 60], valid_range="10~60秒")
        ]
        db.add_all(membership_funcs)
        print("已插入 6 条隶属函数参数。")

        # ==========================================
        # 3. 插入模糊知识规则 (覆盖 9 种组合)
        # ==========================================
        fuzzy_rules = [
            # 组合1: 大 / 小
            FuzzyKnowledge(rule_name="南北极度拥挤规则", condition_ns="大", condition_ew="小", target_direction="ns_l", result_time="长", weight=1.0, description="南北车多东西车少，南北左转给长绿灯"),
            FuzzyKnowledge(rule_name="东西避让规则", condition_ns="大", condition_ew="小", target_direction="ew_l", result_time="短", weight=1.0, description="东西车少南北车多，东西左转赶紧变红"),
            
            # 组合2: 小 / 大
            FuzzyKnowledge(rule_name="东西极度拥挤规则", condition_ns="小", condition_ew="大", target_direction="ew_sr", result_time="长", weight=1.0, description="东西车多南北车少，东西直行给长绿灯"),
            FuzzyKnowledge(rule_name="南北避让规则", condition_ns="小", condition_ew="大", target_direction="ns_l", result_time="短", weight=1.0, description="南北车少东西车多，南北左转赶紧变红"),

            # 组合3: 中 / 中
            FuzzyKnowledge(rule_name="均匀车流规则-南北", condition_ns="中", condition_ew="中", target_direction="ns_sr", result_time="中", weight=0.8, description="车流差不多，南北直行给中等绿灯"),
            FuzzyKnowledge(rule_name="均匀车流规则-东西", condition_ns="中", condition_ew="中", target_direction="ew_sr", result_time="中", weight=0.8, description="车流差不多，东西直行给中等绿灯"),

            # 组合4: 大 / 大
            FuzzyKnowledge(rule_name="全面拥堵规则-南北", condition_ns="大", condition_ew="大", target_direction="ns_l", result_time="中", weight=0.9, description="都很堵，南北左转给中等绿灯轮流放行"),
            FuzzyKnowledge(rule_name="全面拥堵规则-东西", condition_ns="大", condition_ew="大", target_direction="ew_sr", result_time="中", weight=0.9, description="都很堵，东西直行给中等绿灯轮流放行"),

            # 组合5: 小 / 小
            FuzzyKnowledge(rule_name="畅通规则-南北", condition_ns="小", condition_ew="小", target_direction="ns_sr", result_time="短", weight=0.7, description="都没车，南北直行给短绿灯快速切换"),
            FuzzyKnowledge(rule_name="畅通规则-东西", condition_ns="小", condition_ew="小", target_direction="ew_l", result_time="短", weight=0.7, description="都没车，东西左转给短绿灯快速切换"),

            # 组合6: 中 / 小 (对应日志里的状态)
            FuzzyKnowledge(rule_name="偏向南北规则-直行", condition_ns="中", condition_ew="小", target_direction="ns_sr", result_time="中", weight=0.9, description="南北中等东西少，南北直行给中等绿灯"),
            FuzzyKnowledge(rule_name="偏向南北规则-左转", condition_ns="中", condition_ew="小", target_direction="ns_l", result_time="中", weight=0.9, description="南北中等东西少，南北左转给中等绿灯"),
            FuzzyKnowledge(rule_name="压缩东西规则", condition_ns="中", condition_ew="小", target_direction="ew_sr", result_time="短", weight=0.9, description="东西车少，压缩东西绿灯时间"),

            # 组合7: 小 / 中
            FuzzyKnowledge(rule_name="偏向东西规则", condition_ns="小", condition_ew="中", target_direction="ew_l", result_time="中", weight=0.9, description="东西中等南北少，东西左转给中等绿灯"),
            FuzzyKnowledge(rule_name="压缩南北规则", condition_ns="小", condition_ew="中", target_direction="ns_sr", result_time="短", weight=0.9, description="南北车少，压缩南北绿灯时间"),

            # 组合8: 大 / 中
            FuzzyKnowledge(rule_name="拥堵偏向南北", condition_ns="大", condition_ew="中", target_direction="ns_sr", result_time="长", weight=0.9, description="南北大东西中，南北直行给长绿灯"),
            FuzzyKnowledge(rule_name="拥堵压缩东西", condition_ns="大", condition_ew="中", target_direction="ew_l", result_time="短", weight=0.8, description="南北大东西中，东西左转适当缩短"),

            # 组合9: 中 / 大
            FuzzyKnowledge(rule_name="拥堵偏向东西", condition_ns="中", condition_ew="大", target_direction="ew_sr", result_time="长", weight=0.9, description="东西大南北中，东西直行给长绿灯"),
            FuzzyKnowledge(rule_name="拥堵压缩南北", condition_ns="中", condition_ew="大", target_direction="ns_l", result_time="短", weight=0.8, description="东西大南北中，南北左转适当缩短"),
        ]
        db.add_all(fuzzy_rules)
        print("已插入 17 条模糊控制规则。")

        db.commit()
        print("🎉 所有知识库数据初始化成功！")

    except Exception as e:
        db.rollback()
        print(f"❌ 初始化失败: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    init_knowledge_base()