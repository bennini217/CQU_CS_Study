from sqlalchemy.orm import Session
from sqlalchemy import text
from app.database import SessionLocal, engine, Base
from app.models.user import User

def add_user():
    # 既然我们修改了模型，增加学号，如果已有表可能不兼容，直接drop并重建users表
    # 避免影响其他表，只drop users
    print("Recreating users table...")
    User.__table__.drop(engine, checkfirst=True)
    User.__table__.create(engine, checkfirst=True)
    
    db = SessionLocal()
    try:
        new_user = User(name="王竹清", student_id="20230485")
        db.add(new_user)
        db.commit()
        print("用户创建成功！")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        db.close()

if __name__ == "__main__":
    add_user()
