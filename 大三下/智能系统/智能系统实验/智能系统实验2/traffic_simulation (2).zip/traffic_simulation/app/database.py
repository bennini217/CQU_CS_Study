# app/database.py
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from contextlib import contextmanager

# 数据库配置
db_url = 'mysql+pymysql://root:000000@127.0.0.1:3306/traffic?charset=utf8mb4&autocommit=true'
engine = create_engine(db_url, pool_pre_ping=True, pool_recycle=3600)

# 会话本地
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

# 数据库会话依赖
def get_db() -> Session:
    """
    获取数据库会话，每个请求独立
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()