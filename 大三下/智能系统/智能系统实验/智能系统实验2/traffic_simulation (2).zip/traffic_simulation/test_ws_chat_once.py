"""
通过 WebSocket 测一条消息（会触发推理 + 写 traffic_logs）。

用法:
  1) 先启动后端: python run.py
  2) 安装依赖（仅需一次）: pip install websockets
  3) 在本目录执行: python test_ws_chat_once.py

地址默认 ws://127.0.0.1:8000/ws/chat
"""
from __future__ import annotations

import asyncio
import json

import websockets


PAYLOAD = {
    "carInfo": [
        {"id": 0, "carNumber": 10},
        {"id": 1, "carNumber": 10},
        {"id": 2, "carNumber": 3},
        {"id": 3, "carNumber": 3},
    ],
    "signals": [
        {"id": 0, "light": "red"},
        {"id": 1, "light": "green"},
        {"id": 2, "light": "red"},
        {"id": 3, "light": "red"},
    ],
}


async def main() -> None:
    uri = "ws://127.0.0.1:8000/ws/chat"
    async with websockets.connect(uri) as ws:
        await ws.send(json.dumps(PAYLOAD, ensure_ascii=False))
        reply = await ws.recv()
        print("服务器返回:", reply)


if __name__ == "__main__":
    asyncio.run(main())
