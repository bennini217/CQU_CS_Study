"""
本地测试模糊推理 reason_process（不启动 HTTP 服务）。

用法（在 traffic_simulation 目录下）:
  python test_reason_local.py

前提: MySQL 已建库 traffic，已执行过 python init_knowledge.py（库里有隶属函数和模糊规则）。
"""
from __future__ import annotations

from app.database import Base, engine
from app.models.traffic_log import TrafficLog  # noqa: F401
from app.models.user import User  # noqa: F401
from app.models.knowledge import CredibilityKnowledge, MembershipFunction, FuzzyKnowledge  # noqa: F401
from app.service.reason import reason_service


def main() -> None:
    Base.metadata.create_all(bind=engine)

    # carInfo: id 0 南北左转, 1 南北直右, 2 东西左转, 3 东西直右
    case_a = [
        {"id": 0, "carNumber": 28},
        {"id": 1, "carNumber": 28},
        {"id": 2, "carNumber": 2},
        {"id": 3, "carNumber": 2},
    ]
    case_b = [
        {"id": 0, "carNumber": 1},
        {"id": 1, "carNumber": 1},
        {"id": 2, "carNumber": 30},
        {"id": 3, "carNumber": 30},
    ]

    print("=== 用例 A：南北总车流明显多于东西 ===")
    print("carInfo:", case_a)
    print("light_times [ns_l, ns_sr, ew_l, ew_sr]:", reason_service.reason_process(case_a))

    print()
    print("=== 用例 B：东西总车流明显多于南北 ===")
    print("carInfo:", case_b)
    print("light_times [ns_l, ns_sr, ew_l, ew_sr]:", reason_service.reason_process(case_b))


if __name__ == "__main__":
    main()
