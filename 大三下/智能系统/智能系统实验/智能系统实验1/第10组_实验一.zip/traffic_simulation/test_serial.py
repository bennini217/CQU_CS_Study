import serial
import time

print("尝试连接 COM3...")
try:
    # 1. 打开串口
    ser = serial.Serial("COM3", 9600, timeout=1)
    print("连接成功！Arduino 正在重启，等待 2 秒钟...")
    
    # 极度关键：Python 打开串口时，Arduino 会自动重启。
    # 必须等待2秒钟让 Arduino 启动完毕，否则前几个数据会被吞掉！
    time.sleep(2) 

    # 2. 循环发送状态 1, 2, 3, 4
    for state in ['1', '2', '3', '4']:
        print(f"正在发送状态: {state} (应该看到对应的绿灯亮起)")
        ser.write(state.encode()) # 发送字符
        ser.flush()               # 强制推出去
        time.sleep(3)             # 每个状态保持 3 秒，方便肉眼观察
        
    ser.close()
    print("测试完毕，串口已关闭。")

except Exception as e:
    print(f"发生错误: {e}")
