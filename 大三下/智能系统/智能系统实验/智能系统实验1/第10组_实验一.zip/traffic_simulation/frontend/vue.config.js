const { defineConfig } = require('@vue/cli-service')

const AutoImport = require('unplugin-auto-import/webpack')
const Components = require('unplugin-vue-components/webpack')
const { ElementPlusResolver } = require('unplugin-vue-components/resolvers')



module.exports = defineConfig({
  transpileDependencies: true,
  productionSourceMap: false,//隐藏源码
  lintOnSave:false,
  assetsDir: 'static',
  devServer: {
    // proxy: 'http://127.0.0.1:8000'
    proxy: {
      // 代理普通 HTTP 请求
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
        ws: true, // 启用 WebSocket 代理
        // 可选的路径重写
        // pathRewrite: { '^/api': '' }
      },
      // 显式代理您的 WebSocket 路径
      '/ws/chat': {
        target: 'ws://127.0.0.1:8000',
        ws: true,
        changeOrigin: true,
        // 注意：如果您的 WebSocket 路径本身就叫 /chat，这里不需要重写
        // pathRewrite: { '^/chat': '' }
      }
    }
  },
  configureWebpack: {
    plugins: [
      AutoImport({
        resolvers: [ElementPlusResolver(),]
      }),
      Components({
        resolvers: [ElementPlusResolver()]
      })
    ]
  }
})

