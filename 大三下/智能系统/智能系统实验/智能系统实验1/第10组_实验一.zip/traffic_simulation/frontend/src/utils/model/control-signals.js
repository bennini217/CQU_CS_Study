/* eslint-disable */
import { reactive } from 'vue';
import settings from '../settings'
import moment from 'moment';
require('../helpers');

// settings = require('../settings');

var ControlSignals, random, 
    __bind = function (fn, me) { return function () { return fn.apply(me, arguments); }; },
    __indexOf = [].indexOf || function (item) { for (var i = 0, l = this.length; i < l; i++) { if (i in this && this[i] === item) return i; } return -1; };

random = Math.random;

ControlSignals = (function () {
    function ControlSignals(intersection) {
        this.intersection = intersection;
        this.onTick = __bind(this.onTick, this);
        this.flipMultiplier = random();
        this.phaseOffset = 100 * random();
        this.time = new Date().getTime();
        this.preTime = new Date().getTime();
        this.stateNum = Math.floor(400 * random() / 100);
    }

    ControlSignals.copy = function (controlSignals, intersection) {
        var result;
        if (controlSignals == null) {
            return new ControlSignals(intersection);
        }
        result = Object.create(ControlSignals.prototype);
        result.flipMultiplier = controlSignals.flipMultiplier;
        result.time = result.phaseOffset = controlSignals.phaseOffset;
        result.preTime = result.phaseOffset = controlSignals.phaseOffset;
        result.stateNum = 0;
        result.intersection = intersection;
        return result;
    };

    ControlSignals.prototype.toJSON = function () {
        var obj;
        return obj = {
            flipMultiplier: this.flipMultiplier,
            phaseOffset: this.phaseOffset
        };
    };

    ControlSignals.prototype.states = [['L', '', 'L', ''], ['FR', '', 'FR', ''], ['', 'L', '', 'L'], ['', 'FR', '', 'FR']];

    ControlSignals.STATE = [
        {
            RED: 0,
            GREEN: 1
        }
    ];

    ControlSignals.property('flipInterval', {
        get: function () {
            var flipInterval = (5 + 5 * Math.random()).toFixed(0);//(0.1 + 0.05 * this.flipMultiplier) * settings.lightsFlipInterval;
            var list = []
            if(world.curIntersection && this.intersection.id === world.curIntersection.curIntersection.id){
                if(world.curIntersection.curIntersection.controlSignalsState){
                    var signalsStates = world.curIntersection.curIntersection.controlSignalsState
                    list = [parseInt(signalsStates[0].flipInterval), parseInt(signalsStates[1].flipInterval), parseInt(signalsStates[2].flipInterval), parseInt(signalsStates[2].flipInterval)]
                }else {
                    list = [flipInterval,flipInterval,flipInterval,flipInterval]
                }
            } else {
                list = [flipInterval,flipInterval,flipInterval,flipInterval]
            }
            return list;
        },

        set: function(list){
            if(list.length && list.length === 4){
                this.flipInterval = [...list]
            }
        }
    });

    ControlSignals.prototype._decode = function (str) {
        var state;
        state = [0, 0, 0];
        if (__indexOf.call(str, 'L') >= 0) {
            state[0] = 1;
        }
        if (__indexOf.call(str, 'F') >= 0) {
            state[1] = 1;
        }
        if (__indexOf.call(str, 'R') >= 0) {
            state[2] = 1;
        }
        return state;
    };

    ControlSignals.property('state', {
        get: function () {
            var stringState, x, _i, _len, _results;
            stringState = this.states[this.stateNum % this.states.length];
            if (this.intersection.roads.length <= 2) {
                stringState = ['LFR', 'LFR', 'LFR', 'LFR'];
            }
            _results = [];
            for (_i = 0, _len = stringState.length; _i < _len; _i++) {
                x = stringState[_i];
                _results.push(this._decode(x));
            }
            return _results;
        }
    });

    ControlSignals.prototype.flip = function () {

        this.stateNum += 1;

        if(world.curIntersection && this.intersection.id === world.curIntersection.curIntersection.id){
            world.curIntersection.curIntersection.controlSignalsState = [
                {position:'南北',direct: '左', flipInterval:this.flipInterval[0], light: this.state[0][0]===1?'green':'red'},
                {position:'南北',direct: '直右', flipInterval:this.flipInterval[1], light: this.state[0][1]===1?'green':'red'},
                {position:'东西',direct: '左', flipInterval:this.flipInterval[2], light: this.state[1][0]===1?'green':'red'},
                {position:'东西',direct: '直右', flipInterval:this.flipInterval[3], light: this.state[1][1]===1?'green':'red'}
            ]
            world.curIntersection.curIntersection.flipInterval = this.flipInterval;
            if(world.socket.readyState===1){
                const inRoads = world.curIntersection.curIntersection.inRoads;
                var signals = [{
                    id:0, position:'南北',direct: '左', flipInterval:this.flipInterval[0], light: this.state[0][0]===1?'green':'red'
                },{
                    id:1, position:'南北',direct: '直右', flipInterval:this.flipInterval[1], light: this.state[0][1]===1?'green':'red'
                },{
                    id:2, position:'东西',direct: '左', flipInterval:this.flipInterval[2], light: this.state[1][0]===1?'green':'red'
                }, {
                    id:3, position:'东西',direct: '直右', flipInterval:this.flipInterval[3], light: this.state[1][1]===1?'green':'red'
                }]

                var carInfo = [{ id:0,carNumber:0},{id:1,carNumber:0},{id:2,carNumber:0},{id:3,carNumber:0}]
                
                for(var i = 0 ; i < inRoads.length ; i ++){
                    var road = inRoads[i];
                    var sourceSideDirection = parseFloat(road.sourceSide.direction.toFixed(2));
                    
                    var lanes = road.lanes;
                    for(var j = 0; j < lanes.length; j ++){
                        var lane = lanes[j];
                        if(lane.isLeftmost){
                            if(sourceSideDirection === 0 || sourceSideDirection === 3.14){
                                var carNumber = Object.keys(lane.carsPositions).length;
                                if(carNumber > carInfo[0].carNumber){
                                    carInfo[0].carNumber = carNumber;
                                }
                            }else{
                                var carNumber = Object.keys(lane.carsPositions).length;
                                if(carNumber > carInfo[2].carNumber){
                                    carInfo[2].carNumber = carNumber;
                                }
                            }
                        }
                        if(lane.isRightmost){
                            if(sourceSideDirection === 0 || sourceSideDirection === 3.14){
                                var carNumber = Object.keys(lane.carsPositions).length;
                                if(carNumber > carInfo[1].carNumber){
                                    carInfo[1].carNumber = carNumber;
                                }
                            }else{
                                var carNumber = Object.keys(lane.carsPositions).length;
                                if(carNumber > carInfo[3].carNumber){
                                    carInfo[3].carNumber = carNumber;
                                }
                            }
                        }
                    }
                }
                world.socket.send(JSON.stringify({signals,carInfo}))
                console.log(moment().format("YYYY-M-D H:m:s:SSS"), signals,carInfo)
            }
        }

         return 1;
    };

    ControlSignals.prototype.onTick = function (delta) {
        // this.time += delta;
        this.time = new Date().getTime();
        if(world.curIntersection && this.intersection.id === world.curIntersection.curIntersection.id){
            
            world.curIntersection.curIntersection.time = this.time
            if(world.curIntersection.curIntersection.controlSignalsState){
                for(var i = 0 ; i < this.flipInterval.length ; i ++){
                    if(this.flipInterval[i] !== world.curIntersection.curIntersection.controlSignalsState[i].flipInterval){
                        this.flipInterval[i] = world.curIntersection.curIntersection.controlSignalsState[i].flipInterval;
                    }
                }
            }else{
                world.curIntersection.curIntersection.controlSignalsState = [
                    {position:'南北',direct: '左', flipInterval:this.flipInterval[0], light: this.state[0][0]===1?'green':'red'},
                    {position:'南北',direct: '直右', flipInterval:this.flipInterval[1], light: this.state[0][1]===1?'green':'red'},
                    {position:'东西',direct: '左', flipInterval:this.flipInterval[2], light: this.state[1][0]===1?'green':'red'},
                    {position:'东西',direct: '直右', flipInterval:this.flipInterval[3], light: this.state[1][1]===1?'green':'red'}
                ]
                world.curIntersection.curIntersection.flipInterval = this.flipInterval
            }
        }

        var stateIndex = this.stateNum % 4;
        

        // if (this.time > this.flipInterval[stateIndex]) {
        if ((this.time - this.preTime) * 1.0 / 1000 > this.flipInterval[stateIndex]) {

            this.flip();
            this.preTime = this.time;
            // this.time -= this.flipInterval[stateIndex];
        }

        if(world.curIntersection && this.intersection.id === world.curIntersection.curIntersection.id){
            world.curIntersection.curIntersection.time = (this.flipInterval[stateIndex] - (this.time - this.preTime) * 1.0 / 1000).toFixed(4);
        }
        return 1;
    };

    // ControlSignals.prototype.onTick = function (delta) {
    //     // this.time += delta;
    //     this.time = new Date().getTime();
    //     if(world.curIntersection && this.intersection.id === world.curIntersection.curIntersection.id){
    //         console.log(this.time, new Date().getTime())
    //         world.curIntersection.time = this.time
    //     }
    //     if ((this.time - this.preTime) * 1.0 / 1000 > this.flipInterval) {
    //         this.flip();
    //         this.preTime = this.time;
    //         // this.time -= this.flipInterval;
    //     }
    //     if(world.curIntersection && this.intersection.id === world.curIntersection.curIntersection.id){
    //         world.curIntersection.time = this.time
    //     }
        
    //     return 1;
    // };

    return ControlSignals;

})();

export default ControlSignals;


