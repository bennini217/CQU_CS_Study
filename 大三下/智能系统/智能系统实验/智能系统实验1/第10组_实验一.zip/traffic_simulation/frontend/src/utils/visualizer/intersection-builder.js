import Tool from './tool';
import Intersection from '../model/intersection';
import { ref } from 'vue';

var ToolIntersectionBuilder,
    __bind = function (fn, me) { return function () { return fn.apply(me, arguments); }; },
    __hasProp = {}.hasOwnProperty,
    __extends = function (child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

require('../helpers');

ToolIntersectionBuilder = (function (_super) {
    __extends(ToolIntersectionBuilder, _super);

    function ToolIntersectionBuilder() {
        this.world = arguments[0].world;
        this.draw = __bind(this.draw, this);
        this.mouseout = __bind(this.mouseout, this);
        this.mousemove = __bind(this.mousemove, this);
        this.mouseup = __bind(this.mouseup, this);
        this.mousedown = __bind(this.mousedown, this);
        this.click = __bind(this.click, this);
        ToolIntersectionBuilder.__super__.constructor.apply(this, arguments);
        this.tempIntersection = null;
        this.tempIntersection2 = null;
        this.mouseDownPos = null;
        this.world.curselectintersection = null;
    }

    ToolIntersectionBuilder.prototype.mousedown = function (e) {
        this.mouseDownPos = this.getCell(e);
        if (e.shiftKey) {
            this.tempIntersection = new Intersection(this.mouseDownPos);
            return e.stopImmediatePropagation();
        }
    };

    ToolIntersectionBuilder.prototype.mouseup = function () {
        if (this.tempIntersection) {
            this.visualizer.world.addIntersection(this.tempIntersection);
            this.tempIntersection = null;
        }
        return this.mouseDownPos = null;
    };

    ToolIntersectionBuilder.prototype.mousemove = function (e) {
        var rect;
        if (this.tempIntersection) {
            rect = this.visualizer.zoomer.getBoundingBox(this.mouseDownPos, this.getCell(e));
            return this.tempIntersection.rect = rect;
        }
    };


    ToolIntersectionBuilder.prototype.mouseout = function () {
        this.mouseDownPos = null;
        return this.tempIntersection = null;
    };

    ToolIntersectionBuilder.prototype.click = function (e) {

        var intersection = this.getHoveredIntersection(this.getCell(e));
        
        if (intersection) {
            intersection.zh_name = ref("路口" + parseInt(intersection.id.replace("intersection","")) % 100);
            if(this.world.curIntersection.curIntersection.id){
                delete this.world.curIntersection.curIntersection.alpha;

                if(this.world.curIntersection.curIntersection.id === intersection.id){
                    delete this.world.curIntersection.curIntersection.alpha;
                    this.world.curIntersection.curIntersection = {};
                }else{
                    this.world.curIntersection.curIntersection = intersection;
                    this.world.curIntersection.curIntersection.alpha = 0.4;
                }
            }else{
                this.world.curIntersection.curIntersection = intersection;
                this.world.curIntersection.curIntersection.alpha = 0.4;
            }
            
        }
    };

    ToolIntersectionBuilder.prototype.draw = function () {
        if (this.tempIntersection) {
            return this.visualizer.drawIntersection(this.tempIntersection, 0.4);
        }
    };

   

    return ToolIntersectionBuilder;

})(Tool);

export default ToolIntersectionBuilder;