<template>
    <div class="d-flex flex-column">
      <div>
        <div class="affix-container d-flex flex-column justify-content-center">
          <el-affix target=".affix-container" position="top" :offset="10" :z-index="1000" :key="1">
            <el-row :gutter="24" class="d-flex flex-row bg-light">
              <el-col :span="7">
                <el-popover placement="bottom" :width="300" trigger="click">
                  <template #reference>
                    <el-button text type="">
                      <el-icon>
                        <Tools />
                      </el-icon>
                      <span>地图设置</span>
                    </el-button>
                  </template>
                  <el-form :model="form">
                    <el-form-item label="地图行数" :label-width="formLabelWidth">
                      <el-input-number v-model="form.row" :min="3" :max="6"/>
                    </el-form-item>
                    <el-form-item label="地图列数" :label-width="formLabelWidth">
                      <el-input-number v-model="form.col" :min="4" :max="8"/>
                    </el-form-item>
                    <el-form-item label="生成道路" :label-width="formLabelWidth">
                      <el-switch v-model="form.isRandom" active-text="随机" inactive-text="全部" style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949"/>
                      <el-popover placement="bottom" :width="200" trigger="hover" content='相邻两路口之间道路生成方式，“随机”表示随机生成，“全部”表示任一相邻两路口均生成道路'>
                        <template #reference>
                          <el-button text><el-icon><Warning /></el-icon></el-button>
                        </template>
                      </el-popover>
                    </el-form-item>
                    <el-form-item label="" label-width="63%">
                      <el-button type="primary" @click="regenerateMap">刷新</el-button>
                    </el-form-item>

                  </el-form>
                </el-popover>
              </el-col>

              <el-col :span="7">
                <el-button text type="" @click="dialogFormVisible = true">
                  <el-icon>
                    <Guide />
                  </el-icon>
                  <span>路况信息</span>
                </el-button>
              </el-col>

              <el-col :span="10">
                <el-dropdown class="h-100 d-flex justify-content-center" @command="handleToolCommand">
                  <span class="el-dropdown-link d-flex align-items-center">
                    <el-icon>
                      <Briefcase style="width: 1.2em; height: 1.2em; " />
                    </el-icon>
                    <span class="ms-1">工具箱</span>
                    <el-icon class="el-icon--right"><arrow-down /></el-icon>
                  </span>
                  <template #dropdown>
                    <el-dropdown-menu>
                      <el-dropdown-item command="save">保存数据</el-dropdown-item>
                      <el-dropdown-item command="clear">清除数据</el-dropdown-item>
                      <el-dropdown-item command="load">重载数据</el-dropdown-item>
                      <el-dropdown-item command="generateMap">初始化数据</el-dropdown-item>
                    </el-dropdown-menu>
                  </template>
                </el-dropdown>
              </el-col>
            
            </el-row>

            
          </el-affix>
        </div>
        
        <div class="affix-container1 d-flex flex-column justify-content-center">
          <el-affix target=".affix-container1" position="top" :offset="52" :z-index="1000" :key="2" class="bg-light">
            <div style="width:300px; " v-show="dialogFormVisible">
              <div class="d-flex flex-row  bg-light"
                style="margin-left: -12px; margin-right: -12px; border-bottom: 1px solid #dadada">
                <div style="width:100%; padding-left: 12px;">
                  <div class="d-flex justify-content-between align-items-center fs-6" style="">
                    <span>路况</span>
                    <el-button text type="" @click="dialogFormVisible = false">
                      <el-icon>
                        <CloseBold />
                      </el-icon>
                    </el-button>
                  </div>
                </div>
              </div>
              <div class="d-flex flex-row pt-3 bg-light" style="margin-left: -12px; margin-right: -12px;">
                <div style="padding-right: 12px; padding-left: 12px;">
                  <el-form :model="form">
                    <div class="d-flex justify-content-between">
                      
                    </div>
                    <el-form-item label="汽车数量" :label-width="formLabelWidth">
                      <el-input-number v-model="form.carsNumber" :min="1" :max="200" @change="changeCarNumber" />
                    </el-form-item>
                    <el-form-item label="平均车速" :label-width="formLabelWidth">
                      <el-input placeholder="Please input" disabled  v-model="form.instantSpeed" />
                    </el-form-item>
                    
                    <el-form-item class="d-flex align-item-center" label="监控路口" :label-width="formLabelWidth">
                      <el-input  placeholder="请点击地图中路口选择" disabled  v-model="curIntersection.curIntersection.zh_name" />
                    </el-form-item>
                    <el-form-item class="d-flex align-item-center" v-for="state in curIntersection.curIntersection.controlSignalsState" :label="state.position + state.direct" :label-width="formLabelWidth">
                      <el-input  placeholder="Please input" class="w-40" disabled :input-style="['background-color:'+state.light+';text-align:center;color:#fff;']" v-model="state.light" />
                      <el-input v-model="state.flipInterval" class="w-40 ms-2"  placeholder="Type something"/>
                    </el-form-item>

                    <el-form-item v-if="(curIntersection.curIntersection.id !== undefined)" label="倒计时" :label-width="formLabelWidth">
                      <el-input placeholder="Please input" disabled  v-model="curIntersection.curIntersection.time" />
                    </el-form-item>
                  </el-form>
                </div>
              </div>
            </div>
          </el-affix>
        </div>
      </div>
      <div class="affix-container2 d-flex flex-column justify-content-center">
        <el-affix target=".affix-container2" position="top" :offset="10" :z-index="1000" :key="1">
          <el-dropdown :hide-on-click="false">
            <span class="el-dropdown-link">
              <el-button type="primary" size="large" circle>
                <el-icon style="vertical-align: middle" :size="25">
                  <Avatar />
                </el-icon>
              </el-button>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item>
                  <router-link style="text-decoration: none; color:#606266;" to="/">
                    <el-icon><HomeFilled /></el-icon>
                    <span class="ms-2">主页</span>
                  </router-link>
                </el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </el-affix>
      </div>
  </div>
  <div>
    <canvas id="canvas">
    </canvas>
  </div>
</template>

<script>
import _ from 'underscore';
import { onMounted, ref, reactive} from 'vue';
import World from '../utils/model/world';
import Visualizer from '../utils/visualizer/visualizer';
import post from '../util.js'
import useWebsockt from '../socket/websocket';
import { useRouter } from 'vue-router'
import { useStore } from 'vuex' // 引入useStore 方法
import {
  Star,
} from '@element-plus/icons-vue'

export default {
  name: 'HelloWorld',
  
  setup(props) {

    const router = useRouter()
    const store = useStore() 

    const user = reactive(JSON.parse(localStorage.getItem("user")))
    console.log(props)
    require('../utils/helpers');
    const formLabelWidth = '30%'
    const form = reactive({
      running: true,
      debug: false,
      isRandom:true,
      row: 4,
      col: 5,
      instantSpeed: 2,
      carsNumber: 100
    })

    

    let world = {}
    let visualizer = {}
    
    const curIntersection = reactive({curIntersection:{}})
    
    const dialogFormVisible = ref(true)
    
    // const socket = useWebsockt(router, "user"+user.client.token, function(webSocket, event, options){
      
    const socket = useWebsockt(router, "user", function(webSocket, event, options){
      // console.log("消息方法",webSocket, event, options);
      var res = JSON.parse(webSocket.data);
      var error = res.error;
      if(error){
        var log = res.log;
        console.log(log);
      }else{
        var data = res;
        console.log(data);
        if(data.type && data.type === "addCar"){
          addCar();
        }
        if(data.type && data.type === "lightTime"){
          set_light_time(data);
        }
      }
    })

    function set_light_time(data){
      if(!curIntersection.curIntersection.id){
        ElMessage({
                message: '请点击地图选择监控路口.',
                type: 'warning',
            })
      } else {
        var  controlSignalsState = data.data;
        curIntersection.curIntersection.flipInterval = controlSignalsState;
        for(var i = 0 ; i < controlSignalsState.length; i ++){
          curIntersection.curIntersection.controlSignalsState[i].flipInterval = controlSignalsState[i]
          
        }
      }
    }

    async function logout() {
      var entity = new FormData();
      var data = {};
      entity.append("entity", JSON.stringify(data));
      console.log(post)
      await post('/logout', entity)
      store.dispatch('removeUser')
      router.push({ name: 'login' })
    }
    

    function regenerateMap(e){
      world.regenerateMap(form.row, form.col, form.isRandom);
      world.curIntersection.curIntersection = {}
    }

    function addCar(e){

      if(!curIntersection.curIntersection.id){
        ElMessage({
                message: '请点击地图选择监控路口.',
                type: 'warning',
            })
      }else{
        world.addCarInCurIntersection()
      }
      
    }

    const handleToolCommand = (key, keyPath) => {
      console.log(key, keyPath)
      if (world instanceof World) {
        world[key]()
      }
    }

    const changeCarNumber = (value) => {
      if (world instanceof World) {
        world.carsNumber = value;
      }
    }

    onMounted(async () => {

     
      // var gui, guiVisualizer, guiWorld;
      //world 地图数据和车辆数据及业务逻辑处理
      world = new World(curIntersection, form, socket);
      window.world = world;
      world.load();
      if (world.intersections.length === 0) {
        world.generateMap();
        world.carsNumber = 100;
      }

      //将world 数据可视化处理
      visualizer = new Visualizer(world);
      visualizer.start();
      
    })
    
    return {
      dialogFormVisible, form, formLabelWidth, curIntersection, 
      handleToolCommand, changeCarNumber,regenerateMap, logout, addCar
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
@import 'bootstrap/dist/css/bootstrap.css';

@import '../assets/css/myicon/iconfont.css';

.affix-container {
  z-index: 4;
  position: absolute;
  top: 30px;
  right: 120px;
  width: 320px;
  height: 35px;
  padding: 5px 10px;

}

.affix-container1 {
  z-index: 4;
  position: absolute;
  top: 62px;
  right: 120px;
  width: 320px;
  padding: 5px 10px;
}

.affix-container2 {
  z-index: 4;
  position: absolute;
  top: 25px;
  right: 10px;
  width: 100px;
  padding: 5px 10px;
}

h3 {
  margin: 40px 0 0;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
.el-dropdown-link:focus-visible{
  outline: -webkit-focus-ring-color auto 0px;
    outline-width: 0px;
}
</style>
../util.js