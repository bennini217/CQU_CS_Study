
require('../helpers');

var Graphics, PI,
    __slice = [].slice;

PI = Math.PI;

/**
 * 画图工具类，画方向，移动对象等
 */

Graphics = (function () {
    function Graphics(ctx) {
        this.ctx = ctx;
    }

    Graphics.prototype.fillRect = function (rect, style, alpha) {
        var _alpha;
        if (style != null) {
            this.ctx.fillStyle = style;
        }
        _alpha = this.ctx.globalAlpha;
        if (alpha != null) {
            this.ctx.globalAlpha = alpha;
        }
        this.ctx.fillRect(rect.left(), rect.top(), rect.width(), rect.height());
        return this.ctx.globalAlpha = _alpha;
    };

    Graphics.prototype.drawRect = function (rect) {
        var point, vertices, _i, _len, _ref;
        this.ctx.beginPath;
        vertices = rect.getVertices();
        this.ctx.beginPath();
        this.moveTo(vertices[0]);
        _ref = vertices.slice(1);
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            point = _ref[_i];
            this.lineTo(point);
        }
        return this.ctx.closePath();
    };

    Graphics.prototype.drawImage = function (image, rect) {
        return this.ctx.drawImage(image, rect.left(), rect.top(), rect.width(), rect.height());
    };

    Graphics.prototype.clear = function (color) {
        this.ctx.fillStyle = color;
        return this.ctx.fillRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
    };

    Graphics.prototype.moveTo = function (point) {
        return this.ctx.moveTo(point.x, point.y);
    };

    Graphics.prototype.lineTo = function (point) {
        return this.ctx.lineTo(point.x, point.y);
    };

    Graphics.prototype.drawLine = function (source, target) {
        this.ctx.beginPath();
        this.moveTo(source);
        return this.lineTo(target);
    };

    Graphics.prototype.drawSegment = function (segment) {
        return this.drawLine(segment.source, segment.target);
    };

    Graphics.prototype.drawCurve = function (curve, width, color) {
        var i, point, pointsNumber, _i;
        pointsNumber = 10;
        this.ctx.lineWidth = width;
        this.ctx.beginPath();
        this.moveTo(curve.getPoint(0));
        for (i = _i = 0; 0 <= pointsNumber ? _i <= pointsNumber : _i >= pointsNumber; i = 0 <= pointsNumber ? ++_i : --_i) {
            point = curve.getPoint(i / pointsNumber);
            this.lineTo(point);
        }
        if (curve.O) {
            this.moveTo(curve.O);
            this.ctx.arc(curve.O.x, curve.O.y, width, 0, 2 * PI);
        }
        if (curve.Q) {
            this.moveTo(curve.Q);
            this.ctx.arc(curve.Q.x, curve.Q.y, width, 0, 2 * PI);
        }
        if (color) {
            return this.stroke(color);
        }
    };

    Graphics.prototype.drawTriangle = function (p1, p2, p3) {
        this.ctx.beginPath();
        this.moveTo(p1);
        this.lineTo(p2);
        return this.lineTo(p3);
    };

    Graphics.prototype.fill = function (style, alpha) {
        var _alpha;
        this.ctx.fillStyle = style;
        _alpha = this.ctx.globalAlpha;
        if (alpha != null) {
            this.ctx.globalAlpha = alpha;
        }
        this.ctx.fill();
        return this.ctx.globalAlpha = _alpha;
    };

    Graphics.prototype.stroke = function (style) {
        this.ctx.strokeStyle = style;
        return this.ctx.stroke();
    };

    Graphics.prototype.polyline = function () {
        var point, points, _i, _len, _ref;
        points = 1 <= arguments.length ? __slice.call(arguments, 0) : [];
        if (points.length >= 1) {
            this.ctx.beginPath();
            this.moveTo(points[0]);
            _ref = points.slice(1);
            for (_i = 0, _len = _ref.length; _i < _len; _i++) {
                point = _ref[_i];
                this.lineTo(point);
            }
            return this.ctx.closePath();
        }
    };

    Graphics.prototype.save = function () {
        return this.ctx.save();
    };

    Graphics.prototype.restore = function () {
        return this.ctx.restore();
    };

    return Graphics;

})();

export default Graphics;