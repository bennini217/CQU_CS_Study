<template>
  
          <el-row class="h-100 el-row row-bg d-flex flex-row justify-content-between align-items-center flex-grow-1">
              <div class="h-100 me-1 d-flex flex-row align-items-center text-light">
                  <!--
                  <button @click ="onHideMenuClickHandler" class="btn btn-light hidden-sm-and-up sm_menu text-center" type="button" style="background-color: #2870ae;border:1">
                      <span id="icon_menu" class="text-light fs-4 icon iconfont icon-menu "></span>
                  </button> -->

                  <!-- <el-button link @click ="updateCollapse" class="hidden-sm-and-up sm_menu">
                      <span id="icon_menu" ref="icon_menu" class="text-light fs-4 icon iconfont" :class="{ 'icon-menu': isCollapse,'icon-close': !isCollapse}"></span>
                  </el-button> -->

                  <a class="ps-4" href="#">
                      <img style="height:60px;" src="../../assets/logo-white4.png" />
                  </a>
                  <!-- <a class="" href="#">
                      <img style="height:1.2rem;" src="../../assets/images/logo_div.png" />
                  </a>
                  <a class="" href="#">
                      <img style="height:1.2rem;" src="../../assets/images/logo_name.png" />
                  </a> -->
              </div>

              <div class="h-100 pe-4 d-flex flex-row justify-content-right text-light">
                <div class="me-1 me-1 d-flex flex-row align-items-center p-3 " >
                    
                    <svg class="icon me-2 text-white" aria-hidden="true">
                        <use xlink:href="#icon-simulator"></use>
                    </svg>
                    <router-link style="text-decoration: none; color:#fff;" to="/preview">虚拟仿真平台</router-link>
                </div>   
              </div>
          </el-row>
      
</template>

<script>
import {  inject, ref } from 'vue'
import post from '../../util.js'
import { useStore } from 'vuex' // 引入useStore 方法
import { useRouter } from 'vue-router'

export default {
  name: 'Header',
  setup() {
    const router = useRouter()

    const store = useStore()  // 该方法用于返回store 实例

    const {isCollapse,updateCollapse} = inject("isCollapse");

    

    return {updateCollapse,isCollapse}
  },
}

</script>
<style>

@import '../../assets/css/myicon/iconfont.css';
@import '../../assets/css/font-awesome/css/font-awesome.css';
@import '../../assets/css/bootstrap/css/bootstrap.min.css';



.el-popper{
    margin-top: 10px !important;
}

.el-dropdown  a {
    color: #000;
    text-decoration: none;
}

.el-dropdown-menu  a {
    color: #000;
    text-decoration: none;
}


.sm_menu{
    width:3rem;
}


.el-divider--horizontal {
    display: block;
    height: 1px;
    width: 100%;
    margin: 10px 0;
    border-top: 1px var(--el-border-color) var(--el-border-style);
}

.el-dropdown-link:focus-visible{
   outline: -webkit-focus-ring-color auto 0px;
    outline-width: 0px;
}

</style>../../util.js