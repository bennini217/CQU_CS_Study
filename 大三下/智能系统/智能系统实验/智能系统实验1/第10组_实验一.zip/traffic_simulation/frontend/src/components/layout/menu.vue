<template>
    <el-menu
      :default-active="activeMenu"
      class="el-menu-vertical-demo"
      background-color="#fff"
      text-color="#000000"
      :unique-opened="false"
      active-text-color="#0d6efd"
      :collapse="isCollapse"
      :collapse-transition="false"
      router
    >
      <el-menu-item index="/">
        <el-icon><House /></el-icon>
        <span>主页</span>
      </el-menu-item>
      
      <!-- 动态生成菜单 -->
      <template v-for="item in menuList" :key="item.path">
        <!-- 有子菜单的情况 -->
        <el-sub-menu v-if="item.children && item.children.length > 0" :index="item.path">
          <template #title>
            <el-icon v-if="item.icon === 'home'"><House /></el-icon>
            <el-icon v-else-if="item.icon === 'setting'"><Setting /></el-icon>
            <el-icon v-else><Menu /></el-icon>
            <span>{{ item.name }}</span>
          </template>
          <el-menu-item
            v-for="child in item.children"
            :key="child.path"
            :index="child.path"
          >
            <el-icon v-if="child.icon === 'home'"><House /></el-icon>
            <el-icon v-else-if="child.icon === 'setting'"><Setting /></el-icon>
            <el-icon v-else><Menu /></el-icon>
            <span>{{ child.name }}</span>
          </el-menu-item>
        </el-sub-menu>
        
        <!-- 无子菜单的情况 -->
        <el-menu-item v-else :index="item.path">
          <el-icon v-if="item.icon === 'home'"><House /></el-icon>
          <el-icon v-else-if="item.icon === 'setting'"><Setting /></el-icon>
          <el-icon v-else><Menu /></el-icon>
          <span>{{ item.name }}</span>
        </el-menu-item>
      </template>
    </el-menu>
  </template>
  
  <script>
  import { computed, watch, ref, onMounted } from 'vue'
  import { useRouter, useRoute } from 'vue-router'
  import { useStore } from 'vuex'
  import {
    House,
    Setting,
    Menu
  } from '@element-plus/icons-vue'
  
  export default {
    name: 'SidebarMenu',
    components: {
      House,
      Setting,
      Menu
    },
    props: {
      isCollapse: {
        type: Boolean,
        default: false
      }
    },
    setup(props, { emit }) {
      const router = useRouter()
      const route = useRoute()
      const store = useStore()
      
      // 当前激活的菜单
      const activeMenu = ref('/')
      
      // 从路由配置生成菜单结构
      const generateMenuFromRoutes = () => {
        const routes = router.getRoutes()
        const menuItems = []
        const processedPaths = new Set()
        
        // 获取所有顶层路由（path不以/开头或只有一个/的路由）
        routes.forEach(route => {
          // 过滤条件：有meta.menu为true，且不是已处理的路径
          if (route.meta?.menu === true && !processedPaths.has(route.path)) {
            const menuItem = {
              name: route.meta.name || route.name || route.path,
              icon: route.meta.icon || 'menu',
              path: route.path,
              type: route.meta.type || '0',
              children: []
            }
            
            // 如果有子路由，处理子路由中的菜单项
            if (route.children && route.children.length > 0) {
              route.children.forEach(childRoute => {
                // 子路由也要有meta.menu标记才显示在菜单中
                if (childRoute.meta?.menu === true) {
                  const childMenuItem = {
                    name: childRoute.meta.name || childRoute.name || childRoute.path,
                    icon: childRoute.meta.icon || 'menu',
                    path: childRoute.path,
                    type: childRoute.meta.type || '1'
                  }
                  menuItem.children.push(childMenuItem)
                  processedPaths.add(childRoute.path)
                }
              })
            }
            
            // 只有有子菜单或明确标记为独立菜单时才添加到主菜单
            if (menuItem.children.length > 0 || route.meta.standalone === true) {
              menuItems.push(menuItem)
              processedPaths.add(route.path)
            }
          }
        })
        
        return menuItems
      }
      
      // 基于用户角色的权限过滤
      const filterMenuByRole = (menuItems) => {
        const user = store.state.user
        if (!user || !user.roles || user.roles.length === 0) {
          return menuItems
        }
        
        // 这里可以根据实际权限逻辑进行过滤
        const userRoles = user.roles
        
        // 过滤菜单项
        return menuItems.filter(menuItem => {
          if (menuItem.requiredRoles && menuItem.requiredRoles.length > 0) {
            return userRoles.some(role => 
              menuItem.requiredRoles.includes(role.name) || 
              menuItem.requiredRoles.some(reqRole => role.permissions?.includes(reqRole))
            )
          }
          return true
        }).map(menuItem => {
          if (menuItem.children && menuItem.children.length > 0) {
            return {
              ...menuItem,
              children: menuItem.children.filter(childItem => {
                if (childItem.requiredRoles && childItem.requiredRoles.length > 0) {
                  return userRoles.some(role => 
                    childItem.requiredRoles.includes(role.name) || 
                    childItem.requiredRoles.some(reqRole => role.permissions?.includes(reqRole))
                  )
                }
                return true
              })
            }
          }
          return menuItem
        })
      }
      
      // 计算属性：菜单列表
      const menuList = computed(() => {
        // 从路由生成基本菜单结构
        const baseMenu = generateMenuFromRoutes()
        
        // 基于用户角色过滤菜单
        const filteredMenu = filterMenuByRole(baseMenu)
        
        return filteredMenu
      })
      
      // 根据当前路由设置激活的菜单
      const setActiveMenu = () => {
        const { path } = route
        
        // 遍历菜单查找匹配的路由
        const findActivePath = (items) => {
          for (const item of items) {
            if (item.path === path || (item.children && item.children.some(child => child.path === path))) {
              return item.path
            }
            if (item.children && item.children.length > 0) {
              const childPath = findActivePath(item.children)
              if (childPath) return item.path
            }
          }
          return path
        }
        
        activeMenu.value = findActivePath(menuList.value) || '/'
      }
      
      // 监听路由变化
      watch(
        () => route.path,
        () => {
          setActiveMenu()
        },
        { immediate: true }
      )
      
      // 监听菜单列表变化
      watch(
        menuList,
        () => {
          setActiveMenu()
        },
        { immediate: true }
      )
      
      // 初始化
      onMounted(() => {
        setActiveMenu()
      })
      
      return {
        activeMenu,
        menuList
      }
    }
  }
  </script>
  
  <style scoped>
  .el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 200px;
    min-height: 400px;
  }
  
  .el-menu {
    border-right: none;
    height: 100vh;
    overflow-y: auto;
  }
  
  .el-menu-item,
  :deep(.el-sub-menu__title) {
    height: 56px;
    line-height: 56px;
  }
  
  .el-menu-item.is-active {
    background-color: #f2f3f3 !important;
  }
  
  .el-menu-item:hover,
  :deep(.el-sub-menu__title:hover) {
    background-color: #f2f3f3 !important;
    color: #0d6efd !important;
  }
  
  /* 滚动条样式 */
  .el-menu::-webkit-scrollbar {
    width: 6px;
  }
  
  .el-menu::-webkit-scrollbar-thumb {
    background-color: #fff;
    border-radius: 3px;
  }
  
  .el-menu::-webkit-scrollbar-track {
    background-color: #fff;
  }
  </style>