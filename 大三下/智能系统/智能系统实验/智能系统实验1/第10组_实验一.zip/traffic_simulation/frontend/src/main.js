import { createApp } from 'vue'
import App from './App.vue'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import axios from 'axios'
import './assets/js/iconfont.js'
import store from './store'
import router from './router'





axios.interceptors.response.use(response => {
  return response
}, error => {
  if (error.response) {
    switch (error.response.status) {
      case 403:
        store.commit('REMOVEUSER')
        router.push({
          path: '/login'
        })
        break
      default:
        return Promise.reject(error)
    }
  }
  return Promise.reject(error)
})

const app = createApp(App).use(router).use(store)
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.mount('#app')
app.config.errorHandler = (err, instance, info) => {
  console.error('Vue error:', err)
  console.error('Error info:', info)
}


