<template>
    <el-container style="height: 100%;min-height: 100%;">
        <el-header class="el-header p-0 d-flex flex-row align-items-center">
            <Header></Header>
        </el-header>

        <el-container class="d-flex" style="height: 100%;min-height: 1000px;">
            <el-aside width="200px" style="" class="aside">
                <div width="200px" class="menu_header">页面导航</div>
                <Menu></Menu>
            </el-aside>
            <el-main>
                <!-- <Main></Main> -->
                <router-view></router-view>
            </el-main>
        </el-container>
    </el-container>
    <!-- <div class="hello">欢迎您，{{user.name}}</div>
    <el-button>I am ElButton</el-button>
    <button @click="logout">退出</button> -->

</template>

<script>
import { reactive, ref, toRaw, provide, toRefs, onBeforeMount, onMounted, computed, defineAsyncComponent,watch  } from 'vue'
import { useStore } from 'vuex' // 引入useStore 方法
import { useRouter } from 'vue-router'
import Main from "./layout/main.vue"
import Header from './layout/header.vue'
import Menu from './layout/menu.vue'
import post from '../util.js'
import {
    Document,
    Menu as IconMenu,
    Location,
    Setting,
} from '@element-plus/icons-vue'
import { update } from 'lodash'




export default {

    name: "Dashboard ",
    setup() {

        const router = useRouter()
        const store = useStore()  // 该方法用于返回store 实例
        
        const isCollapse = ref(false)
        function updateCollapse() {
            isCollapse.value = !isCollapse.value
        }

        function createNewRoute(route_config) {

            const name = route_config.name;
            if (!router.hasRoute(name)) {
                router.addRoute(route_config)
            }
        }

        function routerPush(path) {
            router.push({ name: path })
        }


        // provide('curRouteResource', curRouteResource)
        // provide('updateCurRouteResource', updateCurRouteResource)

        // provide('resourceMap', resourceMap)
        
        // provide('updateResourceMap', updateResourceMap)

        // provide('user', user)
        // provide('updateUser', updateUser)
        
        provide("isCollapse", { isCollapse, updateCollapse })
        provide('createNewRoute', createNewRoute)
        provide('routerPush', routerPush)
        
        

        return {
            updateCollapse, isCollapse
        }
    }

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
@import 'element-plus/theme-chalk/display.css';

@import '../assets/css/myicon/iconfont.css';

@import '../assets/css/font-awesome/css/font-awesome.css';
@import '../assets/css/bootstrap/css/bootstrap.min.css';



.el-header {
    background-color: #2870ae;
    height:80px;
}

.aside {
    box-shadow: rgba(154, 161, 171, 0.15) 0px 0px 35px 0px;
    min-height: 100%;
    border-right: solid 1px var(--el-menu-border-color);
    overflow: hidden;
}

.menu_header {
    background-image: url(../assets/images/waves.png);
    background-repeat: no-repeat;
    background-position: left top;
    background-size: 200px 40px;
    height: 50px;
    text-align: center;
    /* border-right: solid 1px var(--el-menu-border-color); */
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    font-size: 15px;
    font-weight: bold;
}

.el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 200px;
    min-height: 400px;
}
</style>
../util.js