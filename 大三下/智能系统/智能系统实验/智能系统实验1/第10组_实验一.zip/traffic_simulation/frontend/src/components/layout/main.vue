<template>
  <!-- <component :is="currentComponent" :options="options">·</component> -->
  <div>待完善</div>
</template>

<script>
import { reactive, toRefs, watch, inject} from 'vue'
import {  useRoute, onBeforeRouteLeave } from 'vue-router'


export default {
  name: 'Main',
  props: ['model'],
  setup(props) {
    console.log('1-开始创建组件Main-setup')
    

    return {
       
    }
  },
}

</script>
<style scoped lang='less'>

</style>