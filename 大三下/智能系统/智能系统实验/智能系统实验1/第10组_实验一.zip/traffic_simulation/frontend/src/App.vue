<template>
  <router-view></router-view>
</template>

<script>

import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  components:{HelloWorld},
  
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #2c3e50;
  /* margin-top: 60px; */
}

.icon{
  width: 1.1em;
  height: 1.1em;
  vertical-align: -0.15em;
  /* fill:currentColor; */
  overflow: hidden;
}
</style>
