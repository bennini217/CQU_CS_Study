// websocket的域名和端口号的配置
import ReconnectingWebSocket from 'reconnecting-websocket' ;
const BASE_URL = window.location.hostname;
const WS_PORT = window.location.port === ""?window.location.port:":"+window.location.port;
// const WS_ADDRESS = `ws://${BASE_URL}${WS_PORT}/chat`;
const WS_ADDRESS = `ws://127.0.0.1:8000/ws/chat`;


// 测试2：通过 Vue 代理连接
const testProxy = new WebSocket('ws://127.0.0.1:8080/chat');
testProxy.onopen = () => console.log('✅ 通过代理连接成功');
testProxy.onerror = (e) => console.log('❌ 通过代理连接失败', e);
testProxy.onclose = (e) => console.log('🔌 连接关闭', e.code, e.reason);

// 测试1：直接连接后端
const testDirect = new WebSocket('ws://127.0.0.1:8000/ws/chat');
testDirect.onopen = () => console.log('✅ 直接连接后端成功');
testDirect.onerror = (e) => console.log('❌ 直接连接后端失败', e);
testDirect.onclose = (e) => console.log('🔌 连接关闭', e.code, e.reason);

// 测试2：通过当前页面URL构建连接
const testCurrent = new WebSocket(`ws://${window.location.hostname}:8000/ws/chat`);
testCurrent.onopen = () => console.log('✅ 通过当前域名连接成功');
testCurrent.onerror = (e) => console.log('❌ 连接失败', e);


const useWebsockt = (router, cookie, handleMessage) => {

  // const ws = new WebSocket(WS_ADDRESS, encodeURIComponent(cookie) );
  // const ws = new ReconnectingWebSocket(WS_ADDRESS, encodeURIComponent(cookie) );
  
  const ws = new ReconnectingWebSocket(WS_ADDRESS, null, {
    // 添加额外的选项
    maxReconnectionDelay: 10000,
    reconnectionDelayGrowFactor: 1.3,
  } );
  //ws.binaryType = 'arraybuffer'; //可将 WebSocket 对象的 binaryType 属性设为“blob”或“arraybuffer”。默认格式为“blob”（您不必在发送时校正 binaryType 参数）。
  const init = () => {

    ws.addEventListener('open', handleOpen, false);
    ws.addEventListener('close', handleClose, false);
    ws.addEventListener('error', handleError, false);
    ws.addEventListener('message', handleMessage, false);
    
  };

  function handleOpen(e) {

    console.log('WebSocket open', e);

  }

  function handleClose(e) {

    if(e.code===403){
      router.push("/login")
    }
    console.log('WebSocket close', e);

  }

  function handleError(e) {

    console.log('WebSocket error', e);

  }

  init();
  return ws;
};

export default useWebsockt