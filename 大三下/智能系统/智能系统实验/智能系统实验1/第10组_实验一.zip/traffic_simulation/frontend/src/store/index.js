import { createStore } from 'vuex'

export default createStore({
  state: {
    user: {},
  },
  mutations: {
    SAVEUSER: function (state, user) {
      state.user = user
      localStorage.setItem("user", JSON.stringify(user))
    },
    REMOVEUSER:function(state, user) {
      state.user = {}
      localStorage.removeItem('user')
    }
  },
  actions: {
    saveUser(context, user) {
      context.commit('SAVEUSER', user)
    },
    removeUser(context, user) {
      context.commit('REMOVEUSER', user)
    },
  },
  modules: {

  }
})

