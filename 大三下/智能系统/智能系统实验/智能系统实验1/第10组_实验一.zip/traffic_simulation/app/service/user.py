# app/service/user.py
from typing import Optional, List, Dict, Any
from sqlalchemy.orm import Session
from app.service.base import BaseService
from app.dao.user import user_dao
from app.schemas.user import UserCreate, UserUpdate
from app.models.user import User


class UserService(BaseService[User, UserCreate, UserUpdate]):
    """
    User业务逻辑层
    """

    def __init__(self):
        super().__init__(user_dao)

    def get_by_name(self, db: Session, name: str) -> Optional[User]:
        """
        根据姓名查询用户
        """
        return self.dao.get_by_name(db, name=name)

    def search_by_name(self, db: Session, name: str, skip: int = 0, limit: int = 100) -> List[User]:
        """
        根据姓名模糊搜索
        """
        return self.dao.search_by_name(db, name=name, skip=skip, limit=limit)

    def create_user(self, db: Session, *, name: str) -> User:
        """
        创建用户
        """
        # 检查是否已存在
        existing_user = self.get_by_name(db, name=name)
        if existing_user:
            raise ValueError(f"用户 {name} 已存在")

        user_in = UserCreate(name=name)
        return self.create(db, obj_in=user_in)

    def update_user(self, db: Session, *, id: int, name: str) -> Optional[User]:
        """
        更新用户
        """
        # 检查新名称是否已被其他用户使用
        existing_user = self.get_by_name(db, name=name)
        if existing_user and existing_user.id != id:
            raise ValueError(f"用户名 {name} 已被其他用户使用")

        user_update = UserUpdate(name=name)
        return self.update(db, id=id, obj_in=user_update)

    def get_users_with_pagination(
            self, db: Session, skip: int = 0, limit: int = 100
    ) -> Dict[str, Any]:
        """
        获取分页用户列表
        """
        return self.get_multi_with_total(db, skip=skip, limit=limit)

    def search_users_with_pagination(
            self, db: Session, name: str, skip: int = 0, limit: int = 100
    ) -> Dict[str, Any]:
        """
        搜索用户并分页
        """
        return self.search_by_name_with_total(db, name=name, skip=skip, limit=limit)


user_service = UserService()