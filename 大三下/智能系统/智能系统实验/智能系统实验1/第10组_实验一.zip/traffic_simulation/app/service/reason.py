import logging

logger = logging.getLogger(__name__)

class ReasonService:

    def __init__(self):

        pass

    def reason_process(self, carInfos):

        logger.info(f"车流量信息：{carInfos}")

        ####################推理机处理逻辑开始#################

        ####################推理机处理逻辑结束#################

        # 推理机推理结果
        topRight = 10
        eastLeft = 10
        eastRight = 10
        topLeft = 10

        light_times = [topRight, eastLeft, eastRight, topLeft]

        return light_times


reason_service = ReasonService()