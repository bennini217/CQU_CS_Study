# app/service/base.py
from typing import Generic, TypeVar, Optional, List, Dict, Any
from sqlalchemy.orm import Session
from pydantic import BaseModel
from app.dao.base import BaseDAO

ModelType = TypeVar("ModelType")
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)


class BaseService(Generic[ModelType, CreateSchemaType, UpdateSchemaType]):
    """
    Service基类
    """

    def __init__(self, dao: BaseDAO):
        self.dao = dao

    def get(self, db: Session, id: int) -> Optional[ModelType]:
        """
        根据ID查询
        """
        return self.dao.get(db, id=id)

    def get_multi(
            self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[ModelType]:
        """
        分页查询
        """
        return self.dao.get_multi(db, skip=skip, limit=limit)

    def create(self, db: Session, *, obj_in: CreateSchemaType) -> ModelType:
        """
        创建
        """
        return self.dao.create(db, obj_in=obj_in)

    def update(
            self, db: Session, *, id: int, obj_in: UpdateSchemaType
    ) -> Optional[ModelType]:
        """
        更新
        """
        db_obj = self.dao.get(db, id=id)
        if not db_obj:
            return None
        return self.dao.update(db, db_obj=db_obj, obj_in=obj_in)

    def delete(self, db: Session, *, id: int) -> Optional[ModelType]:
        """
        删除
        """
        return self.dao.delete(db, id=id)

    def get_multi_with_total(
            self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> Dict[str, Any]:
        """
        分页查询，返回数据和总数
        """
        return self.dao.get_multi_with_total(db, skip=skip, limit=limit)

    def search_by_name_with_total(
            self, db: Session, name: str, skip: int = 0, limit: int = 100
    ) -> Dict[str, Any]:
        """
        根据姓名搜索，返回数据和总数
        """
        return self.dao.search_by_name_with_total(db, name=name, skip=skip, limit=limit)

    def get_total_count(self, db: Session) -> int:
        """
        获取总记录数
        """
        return self.dao.get_total_count(db)