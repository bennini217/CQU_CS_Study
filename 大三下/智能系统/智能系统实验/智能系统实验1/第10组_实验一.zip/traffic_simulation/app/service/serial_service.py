from functools import wraps

import serial
import logging
import threading
import time
from serial.serialutil import SerialException

logger = logging.getLogger(__name__)


def singleton(cls):
    """
    单例装饰器
    """
    instances = {}

    @wraps(cls)
    def get_instance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]

    return get_instance

@singleton
class SerialService:
    """
    串口服务类 - 单例模式
    处理与硬件设备的串口通信
    """

    def __init__(self):
        """
        初始化串口服务
        """
        print("=== SerialService __init__ 被调用了 ===")
        logger.info("SerialService 初始化开始")

        self.serialPort = "COM3"
        self.baudRate = 9600
        self.ser = None
        self.lock = threading.Lock()

        print("尝试导入 serial 模块...")
        try:
            # 尝试初始化串口连接
            print(f"DEBUG: SerialService 开始初始化，实例ID: {id(self)}")
            # [关键修复] 设置 dtr=False 避免部分板子不断重启
            self.ser = serial.Serial(self.serialPort, self.baudRate, timeout=0.5)
            self.ser.setDTR(False)
            # 等待 Arduino 初始化完成
            time.sleep(2)
            logger.info(f"串口连接成功: {self.serialPort}")

        except SerialException as e:
            # 串口连接失败，记录警告但允许应用继续运行
            logger.warning(f"串口连接失败: {e}")
            logger.warning("应用将以模拟模式运行，不会影响WebSocket功能")
            self.ser = None
        except Exception as e:
            logger.error(f"初始化串口时发生未知错误: {e}")
            self.ser = None

        logger.info("SerialService 初始化完成")

    def write(self, state):
        """
        向串口写入数据

        参数:
            state: 要写入的状态值
        """
        print(f"=== write() 被调用，state={state} ===")
        with self.lock:
            if self.ser is not None and self.ser.is_open:
                try:
                    self.ser.write(str(state).encode())
                    self.ser.flush() # 强制刷新缓冲区，确保数据立刻发给 Arduino
                    logger.info(f"向串口写入数据: {state}")
                    print(f"串口写入成功: {state}")
                except Exception as e:
                    logger.error(f"串口写入失败: {e}")
                    # 尝试重新连接
                    self._reconnect()
            else:
                # 模拟模式：记录但实际不发送
                logger.info(f"[模拟模式] 向串口写入数据: {state}")
                print(f"[模拟模式] 向串口写入数据: {state}")
                # 可以选择返回模拟的响应
                return True

    def readline(self):
        """
        从串口读取一行数据

        返回:
            读取到的数据，如果没有连接则返回空字符串
        """
        with self.lock:
            if self.ser is not None and self.ser.is_open:
                try:
                    # [修复] 如果没有数据进来就不要死等，避免阻塞 write 线程
                    if self.ser.in_waiting > 0:
                        data = self.ser.readline()
                        if data:
                            decoded_data = data.decode().rstrip()
                            logger.debug(f"从串口读取数据: {decoded_data}")
                            return decoded_data
                except Exception as e:
                    logger.error(f"串口读取失败: {e}")
                    # 尝试重新连接
                    self._reconnect()

        # 模拟模式：返回空字符串
        return ""

    def is_connected(self):
        """
        检查串口是否连接成功

        返回:
            bool: 串口是否已连接
        """
        return self.ser is not None and self.ser.is_open

    def _reconnect(self):
        """
        尝试重新连接串口
        """
        logger.info("尝试重新连接串口...")
        try:
            if self.ser is not None:
                self.ser.close()
            self.ser = serial.Serial(self.serialPort, self.baudRate, timeout=0.5)
            logger.info("串口重新连接成功")
        except Exception as e:
            logger.error(f"串口重新连接失败: {e}")
            self.ser = None

    def close(self):
        """
        关闭串口连接
        注意：在单例模式下，关闭连接会关闭整个应用中的串口实例
        """
        if self.ser is not None and self.ser.is_open:
            self.ser.close()
            logger.info("串口连接已关闭")
        self.ser = None


# 创建串口服务单例实例
