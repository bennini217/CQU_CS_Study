# app/middleware.py
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from sqlalchemy.orm import Session
from app.database import SessionLocal
import time
import logging

logger = logging.getLogger(__name__)


class WebSocketCORSMiddleware:
    """
    WebSocket专用的CORS中间件
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "websocket":
            # 为WebSocket连接添加CORS头
            # 这里可以添加特定的WebSocket CORS处理逻辑
            # 例如，检查Origin头
            headers = dict(scope.get("headers", []))
            origin = headers.get(b"origin", b"").decode()

            # 允许所有来源（开发环境）
            if origin:
                # 可以在这里添加更严格的检查
                pass

        # 继续处理
        await self.app(scope, receive, send)


class DBSessionMiddleware(BaseHTTPMiddleware):
    """
    数据库中间件：每个请求创建新的session，请求结束后销毁
    """

    async def dispatch(self, request: Request, call_next):
        # 请求开始时间
        start_time = time.time()

        # 为每个请求创建新的数据库会话
        db = SessionLocal()
        request.state.db = db

        try:
            # 处理请求
            response = await call_next(request)

            # 记录请求日志
            process_time = time.time() - start_time
            logger.info(f"Request: {request.method} {request.url.path} completed in {process_time:.3f}s")

            return response
        except Exception as e:
            # 发生异常时回滚
            db.rollback()
            raise e
        finally:
            # 请求结束后关闭会话
            db.close()
