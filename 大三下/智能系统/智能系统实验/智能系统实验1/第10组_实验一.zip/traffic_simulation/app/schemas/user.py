# app/schemas/user.py
from pydantic import BaseModel, Field
from typing import Optional, List


# 基础Schema
class UserBase(BaseModel):
    name: str = Field(..., max_length=50, description="用户姓名")


# 创建用户Schema
class UserCreate(UserBase):
    pass


# 更新用户Schema
class UserUpdate(BaseModel):
    name: Optional[str] = Field(None, max_length=50, description="用户姓名")


# 用户响应Schema
class UserResponse(UserBase):
    id: int

    class Config:
        orm_mode = True


class PaginatedResponse(BaseModel):
    items: List[UserResponse]
    total: int
    page: int
    size: int
    pages: int