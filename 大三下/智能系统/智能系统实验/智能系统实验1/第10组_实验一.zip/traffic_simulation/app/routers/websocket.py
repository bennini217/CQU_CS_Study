# app/routers/websocket.py
import json
from concurrent.futures import ThreadPoolExecutor
from typing import Set
from fastapi import WebSocket, WebSocketDisconnect, APIRouter
import asyncio
import logging
from app.service.reason import reason_service

# 再次尝试导入
from app.service.serial_service import SerialService
serial_service = SerialService()
print(f"尝试重新实例化，实例ID: {id(serial_service)}")

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/ws", tags=["websocket"])



class ConnectionManager:
    """
    WebSocket连接管理器
    """

    def __init__(self):
        self.active_connections: Set[WebSocket] = set()

    async def connect(self, websocket: WebSocket):
        """
        建立连接
        """
        await websocket.accept()
        self.active_connections.add(websocket)
        logger.info(f"WebSocket连接已建立，当前连接数: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        """
        断开连接
        """
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info(f"WebSocket连接已断开，当前连接数: {len(self.active_connections)}")

    async def send_personal_message(self, message: str, websocket: WebSocket):
        """
        发送个人消息
        """
        await websocket.send_text(message)

    async def broadcast(self, message: str):
        """
        广播消息给所有连接
        """
        if self.active_connections:
            for connection in self.active_connections:
                try:
                    await connection.send_text(message)
                except Exception as e:
                    logger.error(f"广播消息失败: {e}")
                    self.disconnect(connection)


manager = ConnectionManager()



@router.websocket("/chat")
async def websocket_endpoint(websocket: WebSocket):
    """
    WebSocket端点，模拟交通信号灯控制系统，仿真系统、下位机、推理机的通信枢纽
    """

    logger.info(f"接收到WebSocket连接请求")
    logger.info(f"客户端地址: {websocket.client}")
    logger.info(f"Headers: {dict(websocket.headers)}")

    try:
        await manager.connect(websocket)
        logger.info("WebSocket连接已建立")
    except Exception as e:
        logger.error(f"接受WebSocket连接失败: {e}")
        await websocket.close(code=1011, reason=f"Internal Server Error: {str(e)}")
        return

    try:
        while True:
            # 接收客户端消息
            data = await websocket.receive_text()
            logger.info(f"收到WebSocket消息: {data}")

            try:
                message_data = json.loads(data)
                
                
                car_info = message_data['carInfo']
                logger.info(f"推理前车流量数据: {car_info}")
                
                # 调用推理机推理，根据车流量信息推断各个方向的绿灯时长                
                light_times = reason_service.reason_process(car_info)
                logger.info(f"推理后的红绿灯时长: {light_times}")
                # 将绿灯时长返回给仿真系统前端
                await manager.send_personal_message(json.dumps({
                    'type': "lightTime",
                    "data": light_times
                }), websocket)
                
                # 将仿真前端的红绿灯状态转发给下位机
                state = 1 # 状态编码变量，默认第1个状态
                signals = message_data["signals"]
                logger.info(f"交通信号灯状态: {signals}")
                # 查询当前红绿灯状态
                for signal in signals:
                    light = signal["light"]
                    if light == "green":
                        # 前端的id是0-3，下位机需要的是1-4，所以加1
                        state = int(signal["id"]) + 1
                        logger.info(f"绿灯信号: {signal}, 映射下位机状态: {state}")
                # 将状态编码传给下位机
                print(f"准备发送 state={state} 到串口")
                serial_service.write(state)
                print("发送完成")
            except json.JSONDecodeError:
                error_response = {
                    "type": "error",
                    "message": "无效的JSON格式"
                }
                await manager.send_personal_message(json.dumps(error_response), websocket)

            except Exception as e:
                error_response = {
                    "type": "error",
                    "message": f"处理消息时出错: {str(e)}"
                }
                await manager.send_personal_message(json.dumps(error_response), websocket)

    except WebSocketDisconnect:
        manager.disconnect(websocket)

    except Exception as e:
        logger.error(f"WebSocket连接异常: {e}")
        manager.disconnect(websocket)

executor = ThreadPoolExecutor(max_workers=1)



async def send_periodic_updates():
    """
    循环执行， 用于监控避障传感器信号
    """
    last = ""
    while True:
        # 在单独的线程中执行同步阻塞操作
        loop = asyncio.get_event_loop()
        data = await loop.run_in_executor(executor, serial_service.readline)
        #print(f"DEBUG: 读到串口数据: '{data}', 长度={len(data)}")  # 增加长度信息
        if data != "":
            print(f"DEBUG: 读到串口有效数据: '{data}'")

            # 因为 Arduino 端已经做了边缘检测（只有从没遮挡变成遮挡的那一瞬间才会发一次 obstacle），
            # 我们后端直接收到 "obstacle" 就无脑广播加车即可，不需要再判断 last != "obstacle" 了！
        if data == "obstacle":
            await manager.broadcast(json.dumps({
                    'type': "addCar",
                    "data": True
                }))
            logger.info("addCar 广播已发送，当前连接数: {}".format(len(manager.active_connections)))
        # 只有在读到了有效数据时，才更新 last，防止偶尔读到空字符串覆盖了状态
        if data != "":
            last = data
        await asyncio.sleep(0.05)

# 启动定时任务
@router.on_event("startup")
async def startup_event():
    """
    应用启动时启动定时任务
    """
    asyncio.create_task(send_periodic_updates())