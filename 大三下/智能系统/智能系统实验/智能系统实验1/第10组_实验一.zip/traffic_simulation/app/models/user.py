# app/models/user.py
from sqlalchemy import Column, Integer, String
from app.database import Base


class User(Base):
    """
    User模型
    """
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String(50), nullable=False, index=True, comment="用户姓名")

    def __repr__(self):
        return f"<User(id={self.id}, name={self.name})>"