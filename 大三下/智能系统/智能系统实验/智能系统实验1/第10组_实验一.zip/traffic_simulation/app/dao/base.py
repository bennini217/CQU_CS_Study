# app/dao/base.py
from typing import Generic, TypeVar, Type, List, Optional, Dict, Any

from sqlalchemy import func
from sqlalchemy.orm import Session
from pydantic import BaseModel
from app.database import Base

ModelType = TypeVar("ModelType", bound=Base)
CreateSchemaType = TypeVar("CreateSchemaType", bound=BaseModel)
UpdateSchemaType = TypeVar("UpdateSchemaType", bound=BaseModel)


class BaseDAO(Generic[ModelType, CreateSchemaType, UpdateSchemaType]):
    """
    DAO基类
    """

    def __init__(self, model: Type[ModelType]):
        self.model = model

    def get(self, db: Session, id: int) -> Optional[ModelType]:
        """
        根据ID查询
        """
        return db.query(self.model).filter(self.model.id == id).first()

    def get_multi(
            self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> List[ModelType]:
        """
        分页查询
        """
        return db.query(self.model).offset(skip).limit(limit).all()

    def get_by_name(self, db: Session, name: str) -> Optional[ModelType]:
        """
        根据姓名查询
        """
        return db.query(self.model).filter(self.model.name == name).first()

    def create(self, db: Session, *, obj_in: CreateSchemaType) -> ModelType:
        """
        创建记录
        """
        obj_in_data = obj_in.dict()
        db_obj = self.model(**obj_in_data)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def update(
            self, db: Session, *, db_obj: ModelType, obj_in: UpdateSchemaType
    ) -> ModelType:
        """
        更新记录
        """
        update_data = obj_in.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_obj, field, value)
        db.add(db_obj)
        db.commit()
        db.refresh(db_obj)
        return db_obj

    def delete(self, db: Session, *, id: int) -> ModelType:
        """
        删除记录
        """
        obj = db.query(self.model).get(id)
        if obj:
            db.delete(obj)
            db.commit()
        return obj

    def search_by_name(self, db: Session, name: str, skip: int = 0, limit: int = 100) -> List[ModelType]:
        """
        根据姓名模糊查询
        """
        return db.query(self.model).filter(self.model.name.like(f"%{name}%")).offset(skip).limit(limit).all()

    def get_total_count(self, db: Session) -> int:
        """
        获取总记录数
        """
        return db.query(func.count(self.model.id)).scalar()

    def get_multi_with_total(
            self, db: Session, *, skip: int = 0, limit: int = 100
    ) -> Dict[str, Any]:
        """
        分页查询，返回数据和总数
        """
        items = self.get_multi(db, skip=skip, limit=limit)
        total = self.get_total_count(db)

        return {
            "items": items,
            "total": total,
            "page": skip // limit + 1 if limit > 0 else 1,
            "size": limit,
            "pages": (total + limit - 1) // limit if limit > 0 else 1
        }

    def search_by_name_with_total(
            self, db: Session, name: str, skip: int = 0, limit: int = 100
    ) -> Dict[str, Any]:
        """
        根据姓名模糊查询，返回数据和总数
        """
        items = self.search_by_name(db, name=name, skip=skip, limit=limit)
        total = db.query(func.count(self.model.id)).filter(self.model.name.like(f"%{name}%")).scalar()

        return {
            "items": items,
            "total": total,
            "page": skip // limit + 1 if limit > 0 else 1,
            "size": limit,
            "pages": (total + limit - 1) // limit if limit > 0 else 1
        }