# app/dao/user.py
from app.dao.base import BaseDAO
from app.models.user import User
from app.schemas.user import UserCreate, UserUpdate

class UserDAO(BaseDAO[User, UserCreate, UserUpdate]):
    """
    User数据访问对象
    """
    pass

user_dao = UserDAO(User)