# traffic-simulator

# 一、nodejs环境搭建参考

https://zhuanlan.zhihu.com/p/2004975759790477711

前端nodejs版本： v20.11.0
npm版本：8.19.4

# 二、前端

前端基于vue3开发， 工程文件frontend。

## 运行步骤

终端进入frontend目录, 执行如下 步骤 1-2 命令， 步骤3 发布时使用。

### 1. 工程依赖安装

```
npm install
```

### 2. 编译和运行

```
npm run serve
```

### 3. 工程构建打包

```
npm run build
```

# 三、后端

基于Fastapi构建，数据库使用mysql， 使用sqlalchemy

python版本：3.10.11

### 1. 配置虚拟环境

### 2. 终端进入根目录：traffic_simulation

### 3. pip install -r requirements.txt

### 4. 运行 run.py
