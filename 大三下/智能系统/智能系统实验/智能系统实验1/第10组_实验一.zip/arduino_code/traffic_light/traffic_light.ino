// 交通灯下位机程序 (Arduino)
// 定义引脚
// 状态1：南北左转 (红:2, 黄:3, 绿:4)
const int NS_L_R = 2;
const int NS_L_Y = 3;
const int NS_L_G = 4;

// 状态2：南北直行右转 (红:5, 黄:6, 绿:7)
const int NS_SR_R = 5;
const int NS_SR_Y = 6;
const int NS_SR_G = 7;

// 状态3：东西左转 (红:8, 黄:9, 绿:10)
const int EW_L_R = 8;
const int EW_L_Y = 9;
const int EW_L_G = 10;

// 状态4：东西直行右转 (红:11, 黄:12, 绿:13)
const int EW_SR_R = 11;
const int EW_SR_Y = 12;
const int EW_SR_G = 13;

// 避障传感器引脚
const int SENSOR_PIN = A0;

// 记录传感器上一次的状态
int lastSensorValue = LOW;

void setup() {
  // 初始化串口通信，波特率需要与上位机保持一致
  Serial.begin(9600);
  
  // 初始化交通灯引脚为输出模式
  for (int i = 2; i <= 13; i++) {
    pinMode(i, OUTPUT);
  }
  
  // 初始化传感器引脚为输入模式
  pinMode(SENSOR_PIN, INPUT);
  
  // 初始状态全部红灯
  setAllRed();
}

void loop() {
  // 处理上位机发送的交通灯状态命令
  if (Serial.available() > 0) {
    char state = Serial.read();
    
    // [修复] 过滤杂音和换行符，只处理有效的 1-4 字符
    if (state == '1' || state == '2' || state == '3' || state == '4') {
      updateLights(state);
    }
  }
  
  // 处理避障传感器信号（边缘检测，只在状态变化时发送）
  int sensorValue = digitalRead(SENSOR_PIN);
  
  // 只有当当前状态是高电平（检测到障碍物），且上一次状态是低电平时，才发送信号
  if (sensorValue == HIGH && lastSensorValue == LOW) { 
    Serial.println("obstacle"); // 向串口发送信号，触发上位机添加车辆
    delay(50); // 短暂防抖延迟
  }
  
  // 更新上一次的状态记录
  lastSensorValue = sensorValue;
}

// 设置所有灯为红灯
void setAllRed() {
  for (int i = 2; i <= 13; i++) {
    if (i % 3 == 2) { // 2, 5, 8, 11 是红灯引脚
      digitalWrite(i, HIGH);
    } else {
      digitalWrite(i, LOW);
    }
  }
}

// 根据状态码更新绿灯
void updateLights(char state) {
  setAllRed(); // 先全部置为红灯
  
  if (state == '1') {
    // 状态1：南北左转为绿灯
    digitalWrite(NS_L_R, LOW);
    digitalWrite(NS_L_G, HIGH);
  } 
  else if (state == '2') {
    // 状态2：南北方向直行和右转为绿灯
    digitalWrite(NS_SR_R, LOW);
    digitalWrite(NS_SR_G, HIGH);
  } 
  else if (state == '3') {
    // 状态3：东西方向左转为绿灯
    digitalWrite(EW_L_R, LOW);
    digitalWrite(EW_L_G, HIGH);
  } 
  else if (state == '4') {
    // 状态4：东西方向直行和右转为绿灯
    digitalWrite(EW_SR_R, LOW);
    digitalWrite(EW_SR_G, HIGH);
  }
}
